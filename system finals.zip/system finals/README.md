# TORRELIZA Full Stack

Existing TORRELIZA frontend + backend API + SQLite database in one project.

## Start

```bash
npm install
npm start
```

Then open **http://localhost:3000/**.

API health: **http://localhost:3000/api/health**

## Database

SQLite database: `backend/data/burger-house.sqlite`

To recreate/seed the database from scratch, delete that file and run:

```bash
npm run init-db
```

## Demo login

The included database uses `password` for the three demo accounts:

- Admin: `admin@burgerhouse.com` / `password`
- Staff: `staff@burgerhouse.com` / `password`
- Customer: `customer@burgerhouse.com` / `password`

The original frontend files are kept in place. Backend files are under `backend/`.
