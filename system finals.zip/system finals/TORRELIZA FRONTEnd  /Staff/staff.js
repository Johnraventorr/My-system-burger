/* =========================================================
   BURGER HOUSE STAFF SYSTEM
========================================================= */


/* =========================================================
   DEFAULT STAFF
========================================================= */

function createDefaultStaff() {

    const users =
        JSON.parse(
            localStorage.getItem("burgerUsers")
        ) || [];


    const staffExists =
        users.some(
            user =>
                user.email ===
                "staff@burgerhouse.com"
        );


    if (!staffExists) {

        users.push({

            name: "Burger House Staff",

            email: "raventorreliza@gmail.com",

            password: "staff123",

            role: "staff"

        });


        localStorage.setItem(
            "burgerUsers",
            JSON.stringify(users)
        );

    }

}


/* =========================================================
   INITIALIZE
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        createDefaultStaff();


        const path =
            window.location.pathname;


        if (
            path.includes(
                "staff-login.html"
            )
        ) {

            checkLoginPage();

        }


        if (
            path.includes(
                "staff-dashboard.html"
            )
        ) {

            checkStaffAccess();

        }

    }
);


/* =========================================================
   STAFF LOGIN
========================================================= */

function staffLogin() {

    const email =
        document
            .getElementById("staffEmail")
            .value
            .trim()
            .toLowerCase();


    const password =
        document
            .getElementById("staffPassword")
            .value;


    const message =
        document.getElementById(
            "loginMessage"
        );


    if (!email || !password) {

        message.textContent =
            "Please enter your email and password.";

        message.style.color =
            "#e63946";

        return;

    }


    const users =
        JSON.parse(
            localStorage.getItem(
                "burgerUsers"
            )
        ) || [];


    const staff =
        users.find(
            user =>
                user.email === email &&
                user.password === password &&
                user.role === "staff"
        );


    if (!staff) {

        message.textContent =
            "Invalid staff account.";

        message.style.color =
            "#e63946";

        return;

    }


    localStorage.setItem(
        "burgerStaffSession",
        JSON.stringify(staff)
    );


    message.textContent =
        "Login successful!";

    message.style.color =
        "#20854b";


    setTimeout(
        function () {

            window.location.href =
                "staff-dashboard.html";

        },
        500
    );

}


/* =========================================================
   CHECK LOGIN PAGE
========================================================= */

function checkLoginPage() {

    const session =
        JSON.parse(
            localStorage.getItem(
                "burgerStaffSession"
            )
        );


    if (
        session &&
        session.role === "staff"
    ) {

        window.location.href =
            "staff-dashboard.html";

    }

}


/* =========================================================
   CHECK STAFF ACCESS
========================================================= */

function checkStaffAccess() {

    const session =
        JSON.parse(
            localStorage.getItem(
                "burgerStaffSession"
            )
        );


    if (
        !session ||
        session.role !== "staff"
    ) {

        window.location.href =
            "staff-login.html";

        return;

    }


    loadStaffAccount();

    refreshDashboard();

    renderOrders();

    renderRiders();

    renderReviews();

    renderCustomers();

}


/* =========================================================
   STAFF ACCOUNT
========================================================= */

function loadStaffAccount() {

    const staff =
        JSON.parse(
            localStorage.getItem(
                "burgerStaffSession"
            )
        );


    if (!staff) return;


    const elements = {

        staffName:
            document.getElementById(
                "staffName"
            ),

        accountName:
            document.getElementById(
                "accountName"
            ),

        accountEmail:
            document.getElementById(
                "accountEmail"
            )

    };


    if (elements.staffName) {

        elements.staffName.textContent =
            staff.name;

    }


    if (elements.accountName) {

        elements.accountName.textContent =
            staff.name;

    }


    if (elements.accountEmail) {

        elements.accountEmail.textContent =
            staff.email;

    }

}


/* =========================================================
   STAFF LOGOUT
========================================================= */

function staffLogout() {

    localStorage.removeItem(
        "burgerStaffSession"
    );


    window.location.href =
        "staff-login.html";

}


/* =========================================================
   NAVIGATION
========================================================= */

function showSection(
    section,
    button
) {

    document
        .querySelectorAll(
            ".content-section"
        )
        .forEach(sectionElement => {

            sectionElement.classList.remove(
                "active-section"
            );

        });


    const target =
        document.getElementById(
            section + "Section"
        );


    if (target) {

        target.classList.add(
            "active-section"
        );

    }


    document
        .querySelectorAll(
            ".nav-item"
        )
        .forEach(nav => {

            nav.classList.remove(
                "active"
            );

        });


    if (button) {

        button.classList.add(
            "active"
        );

    }


    closeSidebar();

}


function showSectionById(section) {

    const button =
        Array.from(
            document.querySelectorAll(
                ".nav-item"
            )
        ).find(
            item =>
                item
                    .getAttribute("onclick")
                    ?.includes(
                        `'${section}'`
                    )
        );


    showSection(
        section,
        button
    );

}


function toggleSidebar() {

    document
        .querySelector(
            ".sidebar"
        )
        ?.classList.toggle(
            "mobile-open"
        );

}


function closeSidebar() {

    document
        .querySelector(
            ".sidebar"
        )
        ?.classList.remove(
            "mobile-open"
        );

}


/* =========================================================
   DATA HELPERS
========================================================= */

function getOrders() {

    return JSON.parse(
        localStorage.getItem(
            "burgerOrders"
        )
    ) || [];

}


function getReviews() {

    return JSON.parse(
        localStorage.getItem(
            "burgerReviews"
        )
    ) || [];

}


function getUsers() {

    return JSON.parse(
        localStorage.getItem(
            "burgerUsers"
        )
    ) || [];

}


/* =========================================================
   DASHBOARD
========================================================= */

function refreshDashboard() {

    const orders =
        getOrders();


    const reviews =
        getReviews();


    const users =
        getUsers();


    const customers =
        users.filter(
            user =>
                user.role !== "staff"
        );


    const sales =
        orders
            .filter(
                order =>
                    order.status !==
                    "Cancelled"
            )
            .reduce(
                (
                    total,
                    order
                ) =>
                    total +
                    Number(
                        order.total || 0
                    ),
                0
            );


    const average =
        reviews.length
            ? reviews.reduce(
                (
                    sum,
                    review
                ) =>
                    sum +
                    Number(
                        review.rating
                    ),
                0
            ) / reviews.length
            : 0;


    setText(
        "totalOrders",
        orders.length
    );


    setText(
        "totalSales",
        "₱" +
        sales.toFixed(2)
    );


    setText(
        "totalCustomers",
        customers.length
    );


    setText(
        "dashboardRating",
        average.toFixed(1)
    );


    renderRecentOrders();

    renderRecentReviews();

}


/* =========================================================
   RECENT ORDERS
========================================================= */

function renderRecentOrders() {

    const container =
        document.getElementById(
            "recentOrders"
        );


    if (!container) return;


    const orders =
        getOrders();


    const latest =
        [...orders]
            .reverse()
            .slice(0, 5);


    if (!latest.length) {

        container.innerHTML = `

            <div class="empty-state">

                📦

                <p>
                    No orders yet.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        latest.map(
            order => `

                <div class="recent-order">

                    <div>

                        <strong>
                            ${escapeHTML(
                                order.orderId
                            )}
                        </strong>

                        <small>
                            ${escapeHTML(
                                order.customer.name
                            )}
                        </small>

                    </div>

                    <div>

                        <strong>
                            ₱${Number(
                                order.total
                            ).toFixed(2)}
                        </strong>

                        <small>
                            ${escapeHTML(
                                order.status
                            )}
                        </small>

                    </div>

                </div>

            `
        ).join("");

}


/* =========================================================
   RECENT REVIEWS
========================================================= */

function renderRecentReviews() {

    const container =
        document.getElementById(
            "recentReviews"
        );


    if (!container) return;


    const reviews =
        getReviews();


    const latest =
        reviews.slice(0, 4);


    if (!latest.length) {

        container.innerHTML = `

            <div class="empty-state">

                ⭐

                <p>
                    No reviews yet.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        latest.map(
            review => `

                <div class="recent-order">

                    <div>

                        <strong>
                            ${escapeHTML(
                                review.name
                            )}
                        </strong>

                        <small>
                            ${escapeHTML(
                                review.comment
                            )}
                        </small>

                    </div>

                    <div class="review-stars">

                        ${getStars(
                            review.rating
                        )}

                    </div>

                </div>

            `
        ).join("");

}


/* =========================================================
   ORDERS
========================================================= */

function renderOrders() {

    const container =
        document.getElementById(
            "ordersTable"
        );


    if (!container) return;


    const search =
        document
            .getElementById(
                "orderSearch"
            )
            ?.value
            .toLowerCase()
            .trim() || "";


    const filter =
        document
            .getElementById(
                "orderFilter"
            )
            ?.value || "All";


    let orders =
        getOrders();


    orders =
        orders.filter(
            order => {

                const matchesSearch =
                    !search ||
                    order.orderId
                        .toLowerCase()
                        .includes(search) ||
                    order.customer.name
                        .toLowerCase()
                        .includes(search);


                const matchesFilter =
                    filter === "All" ||
                    order.status === filter;


                return (
                    matchesSearch &&
                    matchesFilter
                );

            }
        );


    orders =
        [...orders].reverse();


    if (!orders.length) {

        container.innerHTML = `

            <div class="empty-state">

                📦

                <h3>
                    No orders found
                </h3>

                <p>
                    There are no matching orders.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML = `

        <table class="staff-table">

            <thead>

                <tr>

                    <th>
                        Order
                    </th>

                    <th>
                        Customer
                    </th>

                    <th>
                        Total
                    </th>

                    <th>
                        Rider
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Action
                    </th>

                </tr>

            </thead>

            <tbody>

                ${orders.map(
                    order => `

                        <tr>

                            <td>

                                <span class="order-id">
                                    ${escapeHTML(
                                        order.orderId
                                    )}
                                </span>

                            </td>

                            <td>

                                ${escapeHTML(
                                    order.customer.name
                                )}

                            </td>

                            <td>

                                <strong>
                                    ₱${Number(
                                        order.total
                                    ).toFixed(2)}
                                </strong>

                            </td>

                            <td>

                                🏍️
                                ${escapeHTML(
                                    order.rider?.name ||
                                    "Unassigned"
                                )}

                            </td>

                            <td>

                                ${getStatusBadge(
                                    order.status
                                )}

                            </td>

                            <td>

                                <button
                                    class="action-button"
                                    onclick="openOrderModal('${escapeHTML(
                                        order.orderId
                                    )}')">

                                    View

                                </button>

                            </td>

                        </tr>

                    `
                ).join("")}

            </tbody>

        </table>

    `;

}


/* =========================================================
   ORDER MODAL
========================================================= */

function openOrderModal(orderId) {

    const orders =
        getOrders();


    const order =
        orders.find(
            item =>
                item.orderId === orderId
        );


    if (!order) return;


    const modal =
        document.getElementById(
            "orderModal"
        );


    const details =
        document.getElementById(
            "orderDetails"
        );


    details.innerHTML = `

        <div class="detail-row">

            <strong>
                Order ID
            </strong>

            ${escapeHTML(
                order.orderId
            )}

        </div>


        <div class="detail-row">

            <strong>
                Customer
            </strong>

            ${escapeHTML(
                order.customer.name
            )}

            <br>

            ${escapeHTML(
                order.customer.email
            )}

            <br>

            ${escapeHTML(
                order.customer.phone
            )}

        </div>


        <div class="detail-row">

            <strong>
                Delivery Address
            </strong>

            ${escapeHTML(
                order.address.fullAddress
            )}

        </div>


        <div class="detail-row">

            <strong>
                Rider
            </strong>

            🏍️
            ${escapeHTML(
                order.rider?.name ||
                "Unassigned"
            )}

            <br>

            ${escapeHTML(
                order.rider?.vehicle ||
                ""
            )}

        </div>


        <div class="detail-row">

            <strong>
                Items
            </strong>

            ${order.items.map(
                item => `

                    <div style="
                        display:flex;
                        justify-content:space-between;
                        padding:5px 0;
                    ">

                        <span>
                            ${escapeHTML(
                                item.name
                            )}
                            × ${item.quantity}
                        </span>

                        <strong>
                            ₱${(
                                Number(item.price) *
                                Number(item.quantity)
                            ).toFixed(2)}
                        </strong>

                    </div>

                `
            ).join("")}

        </div>


        <div class="detail-row">

            <strong>
                Total
            </strong>

            <span style="
                color:#e63946;
                font-size:22px;
                font-weight:bold;
            ">

                ₱${Number(
                    order.total
                ).toFixed(2)}

            </span>

        </div>


        <div class="status-control">

            <label>
                Update Order Status
            </label>

            <select
                id="modalStatus">

                ${getStatusOptions(
                    order.status
                )}

            </select>


            <label style="
                margin-top:12px;
            ">

                Rider Location

            </label>

            <input
                id="modalLocation"
                value="${escapeHTML(
                    order.riderLocation ||
                    "Burger House"
                )}"
                style="
                    width:100%;
                    padding:11px;
                    border:1px solid #ddd;
                    border-radius:8px;
                "
            >


            <button
                class="update-status-button"
                onclick="updateOrderStatus('${escapeHTML(
                    order.orderId
                )}')">

                💾 Update Order

            </button>

        </div>

    `;


    modal.style.display =
        "flex";

}


function closeOrderModal() {

    document.getElementById(
        "orderModal"
    ).style.display =
        "none";

}


/* =========================================================
   UPDATE ORDER STATUS
========================================================= */

function updateOrderStatus(orderId) {

    const orders =
        getOrders();


    const index =
        orders.findIndex(
            order =>
                order.orderId ===
                orderId
        );


    if (index === -1) return;


    const status =
        document.getElementById(
            "modalStatus"
        ).value;


    const location =
        document.getElementById(
            "modalLocation"
        ).value.trim();


    orders[index].status =
        status;


    orders[index].riderLocation =
        location ||
        "Burger House";


    localStorage.setItem(
        "burgerOrders",
        JSON.stringify(
            orders
        )
    );


    alert(
        "Order updated successfully!"
    );


    closeOrderModal();

    renderOrders();

    refreshDashboard();

}


/* =========================================================
   RIDERS
========================================================= */

const staffRiders = [

    {
        id: 1,
        name: "Mark",
        vehicle: "🏍️ Motorcycle"
    },

    {
        id: 2,
        name: "John",
        vehicle: "🏍️ Motorcycle"
    },

    {
        id: 3,
        name: "Carlo",
        vehicle: "🛵 Scooter"
    },

    {
        id: 4,
        name: "Ryan",
        vehicle: "🏍️ Motorcycle"
    }

];


function renderRiders() {

    const container =
        document.getElementById(
            "ridersGrid"
        );


    if (!container) return;


    const orders =
        getOrders();


    container.innerHTML =
        staffRiders.map(
            rider => {

                const activeOrder =
                    orders.find(
                        order =>
                            order.rider?.id ===
                            rider.id &&
                            order.status !==
                            "Delivered" &&
                            order.status !==
                            "Cancelled"
                    );


                return `

                    <div class="rider-card">

                        <div class="rider-avatar">

                            ${rider.vehicle.includes(
                                "Scooter"
                            )
                                ? "🛵"
                                : "🏍️"}

                        </div>

                        <h3>
                            ${escapeHTML(
                                rider.name
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                rider.vehicle
                            )}
                        </p>

                        ${
                            activeOrder
                                ? `

                                    <span class="rider-online">

                                        ● Delivering
                                        ${escapeHTML(
                                            activeOrder.orderId
                                        )}

                                    </span>

                                  `
                                : `

                                    <span class="rider-online">

                                        ● Available

                                    </span>

                                  `
                        }

                    </div>

                `;

            }
        ).join("");

}


/* =========================================================
   REVIEWS
========================================================= */

function renderReviews() {

    const container =
        document.getElementById(
            "staffReviews"
        );


    if (!container) return;


    const reviews =
        getReviews();


    const average =
        reviews.length
            ? reviews.reduce(
                (
                    total,
                    review
                ) =>
                    total +
                    Number(
                        review.rating
                    ),
                0
            ) / reviews.length
            : 0;


    setText(
        "staffAverageRating",
        average.toFixed(1)
    );


    setText(
        "staffAverageStars",
        getStars(average)
    );


    setText(
        "staffReviewCount",
        reviews.length
    );


    if (!reviews.length) {

        container.innerHTML = `

            <div class="empty-state">

                ⭐

                <h3>
                    No reviews yet
                </h3>

                <p>
                    Customer reviews will appear here.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        reviews.map(
            review => `

                <div class="staff-review-card">

                    <div class="review-header">

                        <div>

                            <div class="review-user">

                                👤
                                ${escapeHTML(
                                    review.name
                                )}

                            </div>

                            <span class="review-date">

                                ${escapeHTML(
                                    review.date || ""
                                )}

                            </span>

                        </div>

                        <div class="review-stars">

                            ${getStars(
                                review.rating
                            )}

                        </div>

                    </div>


                    <p>

                        "${escapeHTML(
                            review.comment
                        )}"

                    </p>


                    ${
                        review.orderId
                            ? `

                                <small>
                                    Order:
                                    <strong>
                                        ${escapeHTML(
                                            review.orderId
                                        )}
                                    </strong>
                                </small>

                              `
                            : ""
                    }


                    ${
                        review.verified
                            ? `

                                <br>

                                <span class="verified-label">

                                    ✓ Verified Buyer

                                </span>

                              `
                            : ""
                    }

                </div>

            `
        ).join("");

}


/* =========================================================
   CUSTOMERS
========================================================= */

function renderCustomers() {

    const container =
        document.getElementById(
            "customersTable"
        );


    if (!container) return;


    const customers =
        getUsers().filter(
            user =>
                user.role !== "staff"
        );


    if (!customers.length) {

        container.innerHTML = `

            <div class="empty-state">

                👥

                <h3>
                    No customers yet
                </h3>

            </div>

        `;

        return;

    }


    const orders =
        getOrders();


    container.innerHTML = `

        <table class="staff-table">

            <thead>

                <tr>

                    <th>
                        Customer
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Orders
                    </th>

                    <th>
                        Role
                    </th>

                </tr>

            </thead>

            <tbody>

                ${customers.map(
                    customer => {

                        const customerOrders =
                            orders.filter(
                                order =>
                                    order.customer.email ===
                                    customer.email
                            );


                        return `

                            <tr>

                                <td>

                                    <span class="customer-avatar">
                                        👤
                                    </span>

                                    <strong>
                                        ${escapeHTML(
                                            customer.name
                                        )}
                                    </strong>

                                </td>

                                <td>

                                    ${escapeHTML(
                                        customer.email
                                    )}

                                </td>

                                <td>

                                    ${customerOrders.length}

                                </td>

                                <td>

                                    <span class="status-badge status-ready">

                                        Customer

                                    </span>

                                </td>

                            </tr>

                        `;

                    }
                ).join("")}

            </tbody>

        </table>

    `;

}


/* =========================================================
   STATUS HELPERS
========================================================= */

function getStatusOptions(current) {

    const statuses = [

        "Order Received",

        "Preparing",

        "Ready for Pickup",

        "Rider is on the way",

        "Delivered",

        "Cancelled"

    ];


    return statuses.map(
        status => `

            <option
                value="${status}"
                ${status === current
                    ? "selected"
                    : ""}>

                ${status}

            </option>

        `
    ).join("");

}


function getStatusBadge(status) {

    let className =
        "status-received";


    if (
        status ===
        "Preparing"
    ) {

        className =
            "status-preparing";

    }


    if (
        status ===
        "Ready for Pickup"
    ) {

        className =
            "status-ready";

    }


    if (
        status ===
        "Rider is on the way"
    ) {

        className =
            "status-way";

    }


    if (
        status ===
        "Delivered"
    ) {

        className =
            "status-delivered";

    }


    if (
        status ===
        "Cancelled"
    ) {

        className =
            "status-cancelled";

    }


    return `

        <span class="status-badge ${className}">

            ${escapeHTML(
                status
            )}

        </span>

    `;

}


/* =========================================================
   STARS
========================================================= */

function getStars(rating) {

    const rounded =
        Math.round(
            Number(rating)
        );


    return (
        "★".repeat(
            rounded
        ) +
        "☆".repeat(
            5 - rounded
        )
    );

}


/* =========================================================
   TEXT HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(text) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        String(
            text ?? ""
        );


    return div.innerHTML;

}


/* =========================================================
   CLOSE MODAL BY BACKDROP
========================================================= */

window.addEventListener(
    "click",
    function (event) {

        const modal =
            document.getElementById(
                "orderModal"
            );


        if (
            event.target ===
            modal
        ) {

            closeOrderModal();

        }

    }
);


/* =========================================================
   ENTER KEY LOGIN
========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        if (
            event.key ===
            "Enter"
        ) {

            const email =
                document.getElementById(
                    "staffEmail"
                );


            const password =
                document.getElementById(
                    "staffPassword"
                );


            if (
                email &&
                password
            ) {

                staffLogin();

            }

        }

    }
);