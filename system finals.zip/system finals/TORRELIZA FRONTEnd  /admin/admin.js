/* =====================================================
   BURGER HOUSE ADMIN
===================================================== */


/* ================= SECURITY ================= */

if (localStorage.getItem("adminLoggedIn") !== "true") {
    window.location.href = "../index.html";
}


/* ================= PRODUCTS ================= */

const products = [
    {
        name: "Classic Burger",
        price: 99,
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Cheese Burger",
        price: 119,
        image: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Bacon Burger",
        price: 139,
        image: "https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "French Fries",
        price: 59,
        image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Cheese Fries",
        price: 79,
        image: "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Soft Drink",
        price: 45,
        image: "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Iced Tea",
        price: 50,
        image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Burger Combo",
        price: 169,
        image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=80"
    }
];


/* ================= DEFAULT INVENTORY ================= */

const defaultInventory = [
    {
        id: 1,
        name: "Classic Burger",
        category: "Burger",
        stock: 25,
        minimum: 10
    },
    {
        id: 2,
        name: "Cheese Burger",
        category: "Burger",
        stock: 18,
        minimum: 10
    },
    {
        id: 3,
        name: "Bacon Burger",
        category: "Burger",
        stock: 7,
        minimum: 10
    },
    {
        id: 4,
        name: "French Fries",
        category: "Side Dish",
        stock: 30,
        minimum: 10
    },
    {
        id: 5,
        name: "Cheese Fries",
        category: "Side Dish",
        stock: 5,
        minimum: 10
    },
    {
        id: 6,
        name: "Soft Drink",
        category: "Drinks",
        stock: 40,
        minimum: 10
    },
    {
        id: 7,
        name: "Iced Tea",
        category: "Drinks",
        stock: 22,
        minimum: 10
    },
    {
        id: 8,
        name: "Burger Combo",
        category: "Combo",
        stock: 3,
        minimum: 10
    }
];


function getInventory() {

    let inventory =
        JSON.parse(
            localStorage.getItem("burgerInventory")
        );

    if (!Array.isArray(inventory)) {

        inventory = defaultInventory;

        localStorage.setItem(
            "burgerInventory",
            JSON.stringify(inventory)
        );
    }

    return inventory;
}


/* ================= START ================= */

document.addEventListener("DOMContentLoaded", () => {
    loadEverything();
});


function loadEverything() {

    renderDashboard();

    renderOrders();

    renderInventory();

    renderUsers();

    renderProducts();

    renderReviews();

}


/* ================= NAVIGATION ================= */

function openPage(page, button) {

    document.querySelectorAll(".page")
        .forEach(item => {
            item.classList.remove("active");
        });

    const selected =
        document.getElementById(page);

    if (selected) {
        selected.classList.add("active");
    }


    document.querySelectorAll(".nav-item")
        .forEach(item => {
            item.classList.remove("active");
        });

    if (button) {
        button.classList.add("active");
    }


    const titles = {

        dashboard: [
            "Dashboard",
            "Welcome back, Administrator 👋"
        ],

        orders: [
            "Orders",
            "Manage customer orders"
        ],

        inventory: [
            "Inventory",
            "Monitor and manage your stock"
        ],

        users: [
            "Users",
            "Registered customers"
        ],

        products: [
            "Products",
            "Manage your menu"
        ],

        reviews: [
            "Reviews",
            "Customer feedback"
        ]

    };


    document.getElementById("pageTitle")
        .textContent =
        titles[page][0];

    document.getElementById("pageSubtitle")
        .textContent =
        titles[page][1];
}


function openPageByName(page) {

    const items =
        document.querySelectorAll(".nav-item");

    let button = null;

    items.forEach(item => {

        if (
            item.getAttribute("onclick") &&
            item.getAttribute("onclick")
                .includes(`'${page}'`)
        ) {
            button = item;
        }

    });

    openPage(page, button);
}


/* ================= DATA ================= */

function getOrders() {

    return JSON.parse(
        localStorage.getItem("burgerOrders")
    ) || [];
}


function getUsers() {

    return JSON.parse(
        localStorage.getItem("burgerUsers")
    ) || [];
}


function getReviews() {

    return JSON.parse(
        localStorage.getItem("burgerReviews")
    ) || [];
}


/* ================= DASHBOARD ================= */

function renderDashboard() {

    const orders = getOrders();

    const users = getUsers();

    const inventory = getInventory();


    const sales =
        orders.reduce(
            (sum, order) =>
                sum + Number(order.total || 0),
            0
        );


    document.getElementById("totalOrders")
        .textContent = orders.length;


    document.getElementById("totalUsers")
        .textContent = users.length;


    document.getElementById("totalSales")
        .textContent =
        "₱" +
        sales.toLocaleString("en-PH", {
            minimumFractionDigits: 2
        });


    const totalStock =
        inventory.reduce(
            (sum, item) =>
                sum + Number(item.stock || 0),
            0
        );


    document.getElementById("totalInventory")
        .textContent = totalStock;


    document.getElementById("sideOrders")
        .textContent = orders.length;


    document.getElementById("sideUsers")
        .textContent = users.length;


    document.getElementById("sideStock")
        .textContent = totalStock;


    const pending =
        orders.filter(
            o =>
                !o.status ||
                o.status === "Pending"
        ).length;


    document.getElementById("notification")
        .textContent = pending;


    renderRecentOrders();

    renderInventoryAlert();

    renderOrderStatus();
}


/* ================= RECENT ORDERS ================= */

function renderRecentOrders() {

    const container =
        document.getElementById("recentOrders");

    const orders =
        getOrders()
            .slice()
            .reverse()
            .slice(0, 5);


    if (!orders.length) {

        container.innerHTML = `
            <div class="empty">
                📦<br><br>
                No orders yet.
            </div>
        `;

        return;
    }


    let html = `
        <div class="table-wrap">
        <table class="table">

        <thead>
            <tr>
                <th>ORDER</th>
                <th>CUSTOMER</th>
                <th>TOTAL</th>
                <th>STATUS</th>
            </tr>
        </thead>

        <tbody>
    `;


    orders.forEach(order => {

        html += `
            <tr>

                <td>
                    <strong>
                        ${order.id || "-"}
                    </strong>
                </td>

                <td>
                    ${order.customerName || "-"}
                </td>

                <td>
                    ₱${Number(
                        order.total || 0
                    ).toFixed(2)}
                </td>

                <td>
                    ${statusBadge(
                        order.status || "Pending"
                    )}
                </td>

            </tr>
        `;

    });


    html += `
        </tbody>
        </table>
        </div>
    `;


    container.innerHTML = html;
}


/* ================= ORDER STATUS ================= */

function renderOrderStatus() {

    const orders = getOrders();


    const statuses = {
        Pending: 0,
        Preparing: 0,
        "Out for Delivery": 0,
        Delivered: 0
    };


    orders.forEach(order => {

        const status =
            order.status || "Pending";

        if (statuses[status] !== undefined) {
            statuses[status]++;
        }

    });


    document.getElementById("orderStatus")
        .innerHTML = `

        <div class="status-line">
            <span>🟡 Pending</span>
            <strong>${statuses.Pending}</strong>
        </div>

        <div class="status-line">
            <span>🔵 Preparing</span>
            <strong>${statuses.Preparing}</strong>
        </div>

        <div class="status-line">
            <span>🟣 Out for Delivery</span>
            <strong>${statuses["Out for Delivery"]}</strong>
        </div>

        <div class="status-line">
            <span>🟢 Delivered</span>
            <strong>${statuses.Delivered}</strong>
        </div>

    `;
}


/* ================= ORDERS ================= */

function renderOrders() {

    const container =
        document.getElementById("allOrders");

    if (!container) return;


    let orders = getOrders();


    const search =
        document.getElementById("orderSearch")
            ?.value
            .toLowerCase()
            .trim();


    const filter =
        document.getElementById("orderFilter")
            ?.value || "all";


    if (search) {

        orders =
            orders.filter(order =>

                String(order.id || "")
                    .toLowerCase()
                    .includes(search)

                ||

                String(order.customerName || "")
                    .toLowerCase()
                    .includes(search)

            );
    }


    if (filter !== "all") {

        orders =
            orders.filter(
                order =>
                    (order.status || "Pending")
                    === filter
            );
    }


    if (!orders.length) {

        container.innerHTML = `
            <div class="empty">
                No orders found.
            </div>
        `;

        return;
    }


    let html = `
        <div class="table-wrap">

        <table class="table">

        <thead>
            <tr>
                <th>ORDER</th>
                <th>CUSTOMER</th>
                <th>LOCATION</th>
                <th>TOTAL</th>
                <th>STATUS</th>
            </tr>
        </thead>

        <tbody>
    `;


    orders
        .slice()
        .reverse()
        .forEach(order => {

            const realIndex =
                getOrders().findIndex(
                    item =>
                        item.id === order.id
                );


            html += `
                <tr>

                    <td>
                        <strong>
                            ${order.id || "-"}
                        </strong>
                        <br>
                        <small>
                            ${order.date || ""}
                        </small>
                    </td>

                    <td>
                        ${order.customerName || "-"}
                    </td>

                    <td>
                        ${order.municipality || "-"}
                        <br>
                        <small>
                            ${order.barangay || ""}
                        </small>
                    </td>

                    <td>
                        <strong>
                            ₱${Number(
                                order.total || 0
                            ).toFixed(2)}
                        </strong>
                    </td>

                    <td>

                        <select
                            onchange="changeOrderStatus(
                                ${realIndex},
                                this.value
                            )"
                        >

                            <option value="Pending"
                                ${selected(
                                    order.status,
                                    "Pending"
                                )}>
                                Pending
                            </option>

                            <option value="Preparing"
                                ${selected(
                                    order.status,
                                    "Preparing"
                                )}>
                                Preparing
                            </option>

                            <option value="Out for Delivery"
                                ${selected(
                                    order.status,
                                    "Out for Delivery"
                                )}>
                                Out for Delivery
                            </option>

                            <option value="Delivered"
                                ${selected(
                                    order.status,
                                    "Delivered"
                                )}>
                                Delivered
                            </option>

                        </select>

                    </td>

                </tr>
            `;

        });


    html += `
        </tbody>
        </table>
        </div>
    `;


    container.innerHTML = html;
}


function selected(value, target) {

    return (
        (value || "Pending") === target
            ? "selected"
            : ""
    );
}


function changeOrderStatus(index, status) {

    const orders = getOrders();

    if (!orders[index]) return;

    orders[index].status = status;

    localStorage.setItem(
        "burgerOrders",
        JSON.stringify(orders)
    );

    loadEverything();
}


/* ================= INVENTORY ================= */

function renderInventory() {

    const inventory = getInventory();

    const container =
        document.getElementById("inventoryTable");

    if (!container) return;


    const search =
        document.getElementById("inventorySearch")
            ?.value
            .toLowerCase()
            .trim();


    const filter =
        document.getElementById("inventoryFilter")
            ?.value || "all";


    let items = inventory.filter(item => {

        const matchesSearch =
            !search ||
            item.name.toLowerCase()
                .includes(search) ||
            item.category.toLowerCase()
                .includes(search);


        const state =
            getStockState(item);


        const matchesFilter =
            filter === "all" ||
            filter === state;


        return matchesSearch &&
               matchesFilter;
    });


    const total =
        inventory.reduce(
            (sum, item) =>
                sum + Number(item.stock),
            0
        );


    const inStock =
        inventory.filter(
            item =>
                item.stock > item.minimum
        ).length;


    const lowStock =
        inventory.filter(
            item =>
                item.stock > 0 &&
                item.stock <= item.minimum
        ).length;


    const outStock =
        inventory.filter(
            item =>
                item.stock <= 0
        ).length;


    document.getElementById("inventoryCount")
        .textContent = inventory.length;


    document.getElementById("inStockCount")
        .textContent = inStock;


    document.getElementById("lowStockCount")
        .textContent = lowStock;


    document.getElementById("outStockCount")
        .textContent = outStock;


    if (!items.length) {

        container.innerHTML = `
            <div class="empty">
                No inventory found.
            </div>
        `;

        return;
    }


    let html = `
        <div class="table-wrap">

        <table class="table">

        <thead>
            <tr>
                <th>PRODUCT</th>
                <th>CATEGORY</th>
                <th>STOCK</th>
                <th>MINIMUM</th>
                <th>STATUS</th>
                <th>ACTION</th>
            </tr>
        </thead>

        <tbody>
    `;


    items.forEach(item => {

        const index =
            inventory.findIndex(
                x => x.id === item.id
            );


        html += `
            <tr>

                <td>
                    <strong>
                        ${item.name}
                    </strong>
                </td>

                <td>
                    ${item.category}
                </td>

                <td>

                    <div class="stock-controls">

                        <button
                            onclick="changeStock(
                                ${index},
                                -1
                            )">
                            −
                        </button>

                        <span class="stock-number">
                            ${item.stock}
                        </span>

                        <button
                            onclick="changeStock(
                                ${index},
                                1
                            )">
                            +
                        </button>

                    </div>

                </td>

                <td>
                    ${item.minimum}
                </td>

                <td>
                    ${stockBadge(item)}
                </td>

                <td>
                    <button
                        class="refresh"
                        onclick="setStock(
                            ${index}
                        )">
                        Edit
                    </button>
                </td>

            </tr>
        `;

    });


    html += `
        </tbody>
        </table>
        </div>
    `;


    container.innerHTML = html;
}


function getStockState(item) {

    if (Number(item.stock) <= 0) {
        return "out";
    }

    if (
        Number(item.stock) <=
        Number(item.minimum)
    ) {
        return "low";
    }

    return "good";
}


function stockBadge(item) {

    const state =
        getStockState(item);


    if (state === "out") {
        return `<span class="badge out">OUT OF STOCK</span>`;
    }

    if (state === "low") {
        return `<span class="badge low">LOW STOCK</span>`;
    }

    return `<span class="badge good">IN STOCK</span>`;
}


function changeStock(index, amount) {

    const inventory = getInventory();

    if (!inventory[index]) return;


    inventory[index].stock =
        Math.max(
            0,
            Number(
                inventory[index].stock
            ) + amount
        );


    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(inventory)
    );


    loadEverything();
}


function setStock(index) {

    const inventory = getInventory();

    if (!inventory[index]) return;


    const value =
        prompt(
            "Enter new stock quantity:",
            inventory[index].stock
        );


    if (value === null) return;


    const number =
        Number(value);


    if (
        !Number.isInteger(number) ||
        number < 0
    ) {

        alert(
            "Please enter a valid number."
        );

        return;
    }


    inventory[index].stock = number;


    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(inventory)
    );


    loadEverything();
}


function addInventoryItem() {

    const name =
        prompt("Product name:");

    if (!name) return;


    const category =
        prompt("Category:");

    if (!category) return;


    const stock =
        Number(
            prompt(
                "Initial stock:",
                "10"
            )
        );


    if (
        !Number.isInteger(stock) ||
        stock < 0
    ) {

        alert(
            "Invalid stock quantity."
        );

        return;
    }


    const minimum =
        Number(
            prompt(
                "Minimum stock:",
                "10"
            )
        );


    if (
        !Number.isInteger(minimum) ||
        minimum < 0
    ) {

        alert(
            "Invalid minimum stock."
        );

        return;
    }


    const inventory =
        getInventory();


    inventory.push({

        id: Date.now(),

        name: name,

        category: category,

        stock: stock,

        minimum: minimum

    });


    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(inventory)
    );


    loadEverything();
}


/* ================= INVENTORY ALERT ================= */

function renderInventoryAlert() {

    const container =
        document.getElementById(
            "inventoryAlert"
        );


    const low =
        getInventory()
            .filter(
                item =>
                    item.stock <=
                    item.minimum
            );


    if (!low.length) {

        container.innerHTML = `
            <div class="empty">
                ✅<br><br>
                All products have enough stock.
            </div>
        `;

        return;
    }


    let html = "";


    low.forEach(item => {

        html += `

            <div class="alert-item">

                <div class="alert-info">

                    <strong>
                        ${item.name}
                    </strong>

                    <small>
                        ${item.stock} item(s) remaining
                    </small>

                </div>

                ${stockBadge(item)}

            </div>

        `;

    });


    container.innerHTML = html;
}


/* ================= USERS ================= */

function renderUsers() {

    const users = getUsers();

    const container =
        document.getElementById("allUsers");

    if (!container) return;


    document.getElementById("userPageCount")
        .textContent = users.length;


    const search =
        document.getElementById("userSearch")
            ?.value
            .toLowerCase()
            .trim();


    const filtered =
        users.filter(user =>

            !search ||

            String(user.name || "")
                .toLowerCase()
                .includes(search)

            ||

            String(user.email || "")
                .toLowerCase()
                .includes(search)

        );


    if (!filtered.length) {

        container.innerHTML = `
            <div class="empty">
                👥<br><br>
                No registered users found.
            </div>
        `;

        return;
    }


    let html = `
        <div class="table-wrap">

        <table class="table">

        <thead>
            <tr>
                <th>#</th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>STATUS</th>
            </tr>
        </thead>

        <tbody>
    `;


    filtered.forEach((user, index) => {

        html += `
            <tr>

                <td>
                    ${index + 1}
                </td>

                <td>
                    <strong>
                        ${user.name || "Customer"}
                    </strong>
                </td>

                <td>
                    ${user.email || "-"}
                </td>

                <td>
                    <span class="badge good">
                        ACTIVE
                    </span>
                </td>

            </tr>
        `;

    });


    html += `
        </tbody>
        </table>
        </div>
    `;


    container.innerHTML = html;
}


/* ================= PRODUCTS ================= */

function renderProducts() {

    const container =
        document.getElementById(
            "productsGrid"
        );


    container.innerHTML = "";


    products.forEach(product => {

        const div =
            document.createElement("div");


        div.className = "product";


        div.innerHTML = `

            <img
                src="${product.image}"
                alt="${product.name}"
            >

            <div class="product-info">

                <h3>
                    ${product.name}
                </h3>

                <p>
                    Burger House Menu
                </p>

                <div class="product-price">
                    ₱${product.price.toFixed(2)}
                </div>

            </div>

        `;


        container.appendChild(div);

    });
}


/* ================= REVIEWS ================= */

function renderReviews() {

    const reviews = getReviews();


    const average =
        reviews.length
            ? reviews.reduce(
                (sum, review) =>
                    sum +
                    Number(
                        review.rating || 0
                    ),
                0
            ) / reviews.length
            : 0;


    const five =
        reviews.filter(
            review =>
                Number(review.rating) === 5
        ).length;


    document.getElementById(
        "averageRating"
    ).textContent =
        average.toFixed(1);


    document.getElementById(
        "fiveStarCount"
    ).textContent =
        five;


    document.getElementById(
        "reviewTotal"
    ).textContent =
        reviews.length;


    const container =
        document.getElementById(
            "allReviews"
        );


    if (!reviews.length) {

        container.innerHTML = `
            <div class="empty">
                ⭐<br><br>
                No reviews yet.
            </div>
        `;

        return;
    }


    container.innerHTML =
        reviews
            .slice()
            .reverse()
            .map(review => {

                const rating =
                    Number(
                        review.rating || 0
                    );


                return `

                    <div class="review">

                        <div class="review-top">

                            <strong>
                                👤
                                ${review.name || "Customer"}
                            </strong>

                            <small>
                                ${review.date || ""}
                            </small>

                        </div>

                        <div class="stars">
                            ${"★".repeat(rating)}
                            ${"☆".repeat(5 - rating)}
                        </div>

                        <p>
                            ${review.comment || "No comment."}
                        </p>

                    </div>

                `;

            })
            .join("");
}


/* ================= STATUS BADGE ================= */

function statusBadge(status) {

    let className = "pending";


    if (status === "Preparing") {
        className = "preparing";
    }

    if (status === "Out for Delivery") {
        className = "delivery";
    }

    if (status === "Delivered") {
        className = "delivered";
    }


    return `
        <span class="badge ${className}">
            ${status}
        </span>
    `;
}


/* ================= LOGOUT ================= */

function logoutAdmin() {

    if (
        !confirm(
            "Are you sure you want to logout?"
        )
    ) {
        return;
    }


    localStorage.removeItem(
        "adminLoggedIn"
    );


    window.location.href =
        "../index.html";
}