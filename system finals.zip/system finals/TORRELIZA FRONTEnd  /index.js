const ADMIN_EMAIL = "jraventorreliza@gmail.com";
const ADMIN_PASSWORD = "admin123";


/* =========================================================
   MENU
========================================================= */

const menuItems = [

    {
        id: 1,
        name: "Classic Burger",
        category: "Burger",
        price: 99,
        description: "Juicy beef patty with fresh vegetables.",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 2,
        name: "Cheese Burger",
        category: "Burger",
        price: 119,
        description: "Classic burger with melted cheese.",
        image: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 3,
        name: "Bacon Burger",
        category: "Burger",
        price: 139,
        description: "Beef burger with crispy bacon.",
        image: "https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 4,
        name: "French Fries",
        category: "Fries",
        price: 59,
        description: "Crispy golden french fries.",
        image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 5,
        name: "Cheese Fries",
        category: "Fries",
        price: 79,
        description: "Crispy fries with creamy cheese.",
        image: "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 6,
        name: "Soft Drink",
        category: "Drink",
        price: 45,
        description: "Cold and refreshing soft drink.",
        image: "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 7,
        name: "Iced Tea",
        category: "Drink",
        price: 50,
        description: "Refreshing iced tea.",
        image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 8,
        name: "Burger Combo",
        category: "Combo",
        price: 169,
        description: "Burger, fries and drink.",
        image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80"
    }

];


/* =========================================================
   RIDERS
========================================================= */

const riders = [

    {
        id: 1,
        name: "Mark",
        vehicle: "🏍️ Motorcycle"
    },

    {
        id: 2,
        name: "John",
        vehicle: "🏍️ Motorcycle"
    },

    {
        id: 3,
        name: "Carlo",
        vehicle: "🛵 Scooter"
    },

    {
        id: 4,
        name: "Ryan",
        vehicle: "🏍️ Motorcycle"
    }

];


/* =========================================================
   MUNICIPALITIES
========================================================= */

const municipalities = {

    "Oriental Mindoro": [

        "Baco",
        "Bansud",
        "Bongabong",
        "Bulalacao",
        "Calapan City",
        "Gloria",
        "Mansalay",
        "Naujan",
        "Pinamalayan",
        "Pola",
        "Puerto Galera",
        "Roxas",
        "San Teodoro",
        "Socorro",
        "Victoria"

    ],

    "Occidental Mindoro": [

        "Abra de Ilog",
        "Calintaan",
        "Looc",
        "Lubang",
        "Magsaysay",
        "Mamburao",
        "Paluan",
        "Rizal",
        "Sablayan",
        "San Jose",
        "Santa Cruz"

    ]

};


/* =========================================================
   VARIABLES
========================================================= */

let cart =
    JSON.parse(
        localStorage.getItem(
            "burgerCart"
        )
    ) || [];

let selectedRider = null;

let selectedRating = 0;


/* =========================================================
   START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (
            localStorage.getItem(
                "adminLoggedIn"
            ) === "true"
        ) {

            showAdminDashboard();

            return;
        }


        renderMenu();

        renderCart();

        renderReviews();

        updateUserUI();

        renderRiders();

        loadSavedCheckoutInfo();

    }
);


/* =========================================================
   MENU
========================================================= */

function renderMenu(
    category = "All"
) {

    const container =
        document.getElementById(
            "menuContainer"
        );

    if (!container) return;


    let items =
        menuItems;


    if (category !== "All") {

        items =
            menuItems.filter(
                item =>
                    item.category ===
                    category
            );

    }


    container.innerHTML =
        items.map(
            item => `

                <div class="menu-card">

                    <img
                        src="${item.image}"
                        alt="${item.name}"
                    >

                    <div class="menu-info">

                        <h3>
                            ${item.name}
                        </h3>

                        <p>
                            ${item.description}
                        </p>

                        <div class="price">
                            ₱${item.price.toFixed(2)}
                        </div>

                        <button
                            class="add-btn"
                            onclick="addToCart(${item.id})">

                            Add to Cart 🛒

                        </button>

                    </div>

                </div>
            `
        ).join("");

}


function filterItems(
    category,
    button
) {

    renderMenu(category);

    document
        .querySelectorAll(
            ".categories button"
        )
        .forEach(
            btn =>
                btn.classList.remove(
                    "active"
                )
        );

    button.classList.add("active");

}


/* =========================================================
   CART
========================================================= */

function addToCart(id) {

    const product =
        menuItems.find(
            item =>
                item.id === id
        );

    if (!product) return;


    const existing =
        cart.find(
            item =>
                item.id === id
        );


    if (existing) {

        existing.quantity++;

    } else {

        cart.push({

            id: product.id,

            name: product.name,

            price: product.price,

            image: product.image,

            quantity: 1

        });

    }


    saveCart();

    renderCart();

}


function saveCart() {

    localStorage.setItem(
        "burgerCart",
        JSON.stringify(cart)
    );

}


function getCartTotal() {

    return cart.reduce(
        (
            total,
            item
        ) =>
            total +
            item.price *
            item.quantity,
        0
    );

}


function renderCart() {

    const container =
        document.getElementById(
            "cartContainer"
        );

    if (!container) return;


    const count =
        cart.reduce(
            (
                total,
                item
            ) =>
                total +
                item.quantity,
            0
        );


    const total =
        getCartTotal();


    document.getElementById(
        "cartCount"
    ).textContent =
        count;


    document.getElementById(
        "cartTotal"
    ).textContent =
        total.toFixed(2);


    if (!cart.length) {

        container.innerHTML = `

            <div class="empty">

                🛒

                <h3>
                    Your cart is empty
                </h3>

            </div>
        `;

        return;
    }


    container.innerHTML =
        cart.map(
            item => `

                <div class="cart-item">

                    <img
                        src="${item.image}"
                        alt="${item.name}"
                    >

                    <div class="cart-item-info">

                        <h4>
                            ${item.name}
                        </h4>

                        <p>
                            ₱${item.price.toFixed(2)}
                        </p>

                    </div>


                    <div class="quantity">

                        <button
                            onclick="changeQuantity(
                                ${item.id},
                                -1
                            )">

                            −

                        </button>

                        <b>
                            ${item.quantity}
                        </b>

                        <button
                            onclick="changeQuantity(
                                ${item.id},
                                1
                            )">

                            +

                        </button>

                    </div>


                    <button
                        class="remove-btn"
                        onclick="removeFromCart(
                            ${item.id}
                        )">

                        Remove

                    </button>

                </div>
            `
        ).join("");

}


function changeQuantity(
    id,
    amount
) {

    const item =
        cart.find(
            product =>
                product.id === id
        );

    if (!item) return;


    item.quantity += amount;


    if (
        item.quantity <= 0
    ) {

        cart =
            cart.filter(
                product =>
                    product.id !== id
            );

    }


    saveCart();

    renderCart();

}


function removeFromCart(id) {

    cart =
        cart.filter(
            item =>
                item.id !== id
        );

    saveCart();

    renderCart();

}


/* =========================================================
   LOGIN / REGISTER
========================================================= */

function openLogin() {

    document.getElementById(
        "loginModal"
    ).style.display =
        "flex";

}


function closeLogin() {

    document.getElementById(
        "loginModal"
    ).style.display =
        "none";

}


function switchToRegister() {

    closeLogin();

    document.getElementById(
        "registerModal"
    ).style.display =
        "flex";

}


function switchToLogin() {

    closeRegister();

    openLogin();

}


function closeRegister() {

    document.getElementById(
        "registerModal"
    ).style.display =
        "none";

}


/* =========================================================
   REGISTER
========================================================= */

function register() {

    const name =
        document.getElementById(
            "registerName"
        ).value.trim();


    const email =
        document.getElementById(
            "registerEmail"
        ).value
        .trim()
        .toLowerCase();


    const password =
        document.getElementById(
            "registerPassword"
        ).value;


    const message =
        document.getElementById(
            "registerMessage"
        );


    if (
        !name ||
        !email ||
        !password
    ) {

        message.textContent =
            "Please complete all fields.";

        message.style.color =
            "#e63946";

        return;
    }


    const users =
        JSON.parse(
            localStorage.getItem(
                "burgerUsers"
            )
        ) || [];


    if (
        users.some(
            user =>
                user.email === email
        )
    ) {

        message.textContent =
            "Email is already registered.";

        message.style.color =
            "#e63946";

        return;
    }


    users.push({

        name,

        email,

        password

    });


    localStorage.setItem(
        "burgerUsers",
        JSON.stringify(users)
    );


    message.textContent =
        "Account created successfully!";

    message.style.color =
        "#20854b";


    setTimeout(
        switchToLogin,
        800
    );

}


/* =========================================================
   LOGIN
========================================================= */

function login() {

    const email =
        document.getElementById(
            "loginEmail"
        ).value
        .trim()
        .toLowerCase();


    const password =
        document.getElementById(
            "loginPassword"
        ).value;


    const message =
        document.getElementById(
            "loginMessage"
        );


    if (
        email === ADMIN_EMAIL &&
        password === ADMIN_PASSWORD
    ) {

        localStorage.setItem(
            "adminLoggedIn",
            "true"
        );

        localStorage.removeItem(
            "loggedInUser"
        );


        message.textContent =
            "Admin login successful!";

        message.style.color =
            "#20854b";


        setTimeout(
            function () {

                closeLogin();

                showAdminDashboard();

            },
            400
        );


        return;
    }


    const users =
        JSON.parse(
            localStorage.getItem(
                "burgerUsers"
            )
        ) || [];


    const user =
        users.find(
            account =>
                account.email === email &&
                account.password === password
        );


    if (!user) {

        message.textContent =
            "Invalid email or password.";

        message.style.color =
            "#e63946";

        return;
    }


    localStorage.setItem(
        "loggedInUser",
        JSON.stringify(user)
    );


    message.textContent =
        "Login successful!";

    message.style.color =
        "#20854b";


    setTimeout(
        function () {

            closeLogin();

            updateUserUI();

        },
        400
    );

}


/* =========================================================
   USER UI
========================================================= */

function updateUserUI() {

    const user =
        JSON.parse(
            localStorage.getItem(
                "loggedInUser"
            )
        );


    const loginBtn =
        document.getElementById(
            "loginBtn"
        );


    const welcome =
        document.getElementById(
            "userWelcome"
        );


    const logoutBtn =
        document.getElementById(
            "logoutBtn"
        );


    if (!loginBtn) return;


    if (user) {

        loginBtn.classList.add(
            "hidden"
        );

        welcome.classList.remove(
            "hidden"
        );

        logoutBtn.classList.remove(
            "hidden"
        );

        welcome.textContent =
            `Hi, ${user.name}`;

    } else {

        loginBtn.classList.remove(
            "hidden"
        );

        welcome.classList.add(
            "hidden"
        );

        logoutBtn.classList.add(
            "hidden"
        );

    }

}


function logout() {

    localStorage.removeItem(
        "loggedInUser"
    );

    updateUserUI();

}


/* =========================================================
   SETTINGS
========================================================= */

function toggleSettings() {

    document
        .getElementById(
            "settingsMenu"
        )
        .classList.toggle(
            "show"
        );

}


function closeSettings() {

    document
        .getElementById(
            "settingsMenu"
        )
        ?.classList.remove(
            "show"
        );

}


/* =========================================================
   PROFILE
========================================================= */

function openProfile() {

    const user =
        JSON.parse(
            localStorage.getItem(
                "loggedInUser"
            )
        );


    if (!user) {

        openLogin();

        return;
    }


    document.getElementById(
        "profileName"
    ).textContent =
        user.name;


    document.getElementById(
        "profileEmail"
    ).textContent =
        user.email;


    document.getElementById(
        "profileModal"
    ).style.display =
        "flex";

}


function closeProfile() {

    document.getElementById(
        "profileModal"
    ).style.display =
        "none";

}


/* =========================================================
   CHECKOUT
========================================================= */

function openCheckout() {

    if (!cart.length) {

        alert(
            "Your cart is empty."
        );

        return;
    }


    const user =
        JSON.parse(
            localStorage.getItem(
                "loggedInUser"
            )
        );


    if (!user) {

        openLogin();

        return;
    }


    document.getElementById(
        "customerName"
    ).value =
        user.name;


    document.getElementById(
        "customerPhone"
    ).value =
        localStorage.getItem(
            "burgerPhone"
        ) || "";


    document.getElementById(
        "checkoutTotal"
    ).textContent =
        getCartTotal().toFixed(2);


    renderRiders();


    document.getElementById(
        "checkoutModal"
    ).style.display =
        "flex";

}


function closeCheckout() {

    document.getElementById(
        "checkoutModal"
    ).style.display =
        "none";

}


/* =========================================================
   LOCATION
========================================================= */

function updateMunicipalities() {

    const province =
        document.getElementById(
            "customerProvince"
        ).value;


    const select =
        document.getElementById(
            "customerMunicipality"
        );


    select.innerHTML = `
        <option value="">
            Select Municipality / City
        </option>
    `;


    if (
        !municipalities[
            province
        ]
    ) {

        return;
    }


    municipalities[
        province
    ].forEach(
        city => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                city;

            option.textContent =
                city;

            select.appendChild(
                option
            );

        }
    );

}


/* =========================================================
   RIDERS
========================================================= */

function renderRiders() {

    const container =
        document.getElementById(
            "riderContainer"
        );


    if (!container) return;


    container.innerHTML =
        riders.map(
            rider => `

                <div
                    class="rider-card
                    ${
                        selectedRider &&
                        selectedRider.id === rider.id
                            ? "selected"
                            : ""
                    }"

                    onclick="
                        selectRider(
                            ${rider.id}
                        )
                    "
                >

                    <strong>
                        ${rider.name}
                    </strong>

                    <br>

                    ${rider.vehicle}

                    <br>

                    <small>
                        🟢 Available
                    </small>

                </div>
            `
        ).join("");

}


function selectRider(id) {

    selectedRider =
        riders.find(
            rider =>
                rider.id === id
        );


    renderRiders();

}


/* =========================================================
   PLACE ORDER
========================================================= */

function placeOrder() {

    const user =
        JSON.parse(
            localStorage.getItem(
                "loggedInUser"
            )
        );


    if (!user) {

        openLogin();

        return;
    }


    if (!selectedRider) {

        alert(
            "Please choose a rider."
        );

        return;
    }


    const name =
        document
            .getElementById(
                "customerName"
            )
            .value
            .trim();


    const phone =
        document
            .getElementById(
                "customerPhone"
            )
            .value
            .trim();


    const province =
        document
            .getElementById(
                "customerProvince"
            )
            .value;


    const municipality =
        document
            .getElementById(
                "customerMunicipality"
            )
            .value;


    const barangay =
        document
            .getElementById(
                "customerBarangay"
            )
            .value
            .trim();


    const street =
        document
            .getElementById(
                "customerStreet"
            )
            .value
            .trim();


    const landmark =
        document
            .getElementById(
                "customerLandmark"
            )
            .value
            .trim();


    if (
        !name ||
        !phone ||
        !province ||
        !municipality ||
        !barangay ||
        !street
    ) {

        alert(
            "Please complete your delivery information."
        );

        return;
    }


    const orderId =
        "BH-" +
        Math.floor(
            100000 +
            Math.random() *
            900000
        );


    const order = {

        id:
            orderId,

        customerName:
            name,

        customerEmail:
            user.email,

        phone,

        province,

        municipality,

        barangay,

        street,

        landmark,

        rider:
            selectedRider.name,

        payment:
            "Cash on Delivery",

        total:
            getCartTotal(),

        status:
            "Pending",

        date:
            new Date().toLocaleString(),

        items:
            cart.map(
                item => ({

                    name:
                        item.name,

                    quantity:
                        item.quantity,

                    price:
                        item.price

                })
            )

    };


    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    orders.push(order);


    localStorage.setItem(
        "burgerOrders",
        JSON.stringify(orders)
    );


    localStorage.setItem(
        "burgerPhone",
        phone
    );


    createReceipt(order);


    cart = [];

    saveCart();

    renderCart();

    closeCheckout();


    document.getElementById(
        "receiptModal"
    ).style.display =
        "flex";

}


function createReceipt(order) {

    const receipt =
        document.getElementById(
            "receiptContent"
        );


    receipt.innerHTML = `

        <div class="receipt-details">

            <p>
                <span>Order ID</span>
                <b>${order.id}</b>
            </p>

            <p>
                <span>Customer</span>
                <b>${order.customerName}</b>
            </p>

            <p>
                <span>Rider</span>
                <b>🏍️ ${order.rider}</b>
            </p>

            <p>
                <span>Payment</span>
                <b>${order.payment}</b>
            </p>

            <hr>

            ${
                order.items.map(
                    item => `

                        <p>

                            <span>
                                ${item.name}
                                ×${item.quantity}
                            </span>

                            <b>
                                ₱${
                                    (
                                        item.price *
                                        item.quantity
                                    ).toFixed(2)
                                }
                            </b>

                        </p>

                    `
                ).join("")
            }

            <p>

                <strong>
                    TOTAL
                </strong>

                <strong style="color:#e63946">

                    ₱${order.total.toFixed(2)}

                </strong>

            </p>

        </div>

    `;

}


function closeReceipt() {

    document.getElementById(
        "receiptModal"
    ).style.display =
        "none";

}


function printReceipt() {

    window.print();

}


/* =========================================================
   TRACKING
========================================================= */

function openTracking() {

    document.getElementById(
        "trackingModal"
    ).style.display =
        "flex";

}


function closeTracking() {

    document.getElementById(
        "trackingModal"
    ).style.display =
        "none";

}


function trackOrder() {

    const id =
        document
            .getElementById(
                "trackingOrderId"
            )
            .value
            .trim()
            .toLowerCase();


    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const order =
        orders.find(
            item =>
                item.id.toLowerCase() ===
                id
        );


    const result =
        document.getElementById(
            "trackingResult"
        );


    if (!order) {

        result.innerHTML = `
            <p class="message">
                Order not found.
            </p>
        `;

        return;
    }


    result.innerHTML = `

        <div class="tracking-result">

            <h3>
                📦 ${order.id}
            </h3>

            <p>
                Customer:
                <b>
                    ${order.customerName}
                </b>
            </p>

            <p>
                Rider:
                <b>
                    ${order.rider}
                </b>
            </p>

            <p>
                Status:
                <b>
                    ${order.status}
                </b>
            </p>

            <p>
                Total:
                <b>
                    ₱${Number(
                        order.total
                    ).toFixed(2)}
                </b>
            </p>

        </div>

    `;

}


/* =========================================================
   REVIEWS
========================================================= */

function openReview() {

    document.getElementById(
        "reviewModal"
    ).style.display =
        "flex";

}


function closeReview() {

    document.getElementById(
        "reviewModal"
    ).style.display =
        "none";

}


function selectRating(rating) {

    selectedRating =
        rating;


    document
        .querySelectorAll(
            ".star-rating button"
        )
        .forEach(
            (
                button,
                index
            ) => {

                button.classList.toggle(
                    "selected",
                    index < rating
                );

            }
        );


    const labels = [

        "",

        "Very Bad",

        "Bad",

        "Good",

        "Very Good",

        "Excellent"

    ];


    document.getElementById(
        "ratingText"
    ).textContent =
        labels[rating];

}


function submitReview() {

    const name =
        document.getElementById(
            "reviewName"
        ).value.trim();


    const orderId =
        document.getElementById(
            "reviewOrderId"
        ).value.trim();


    const comment =
        document.getElementById(
            "reviewComment"
        ).value.trim();


    if (
        !selectedRating ||
        !name ||
        !orderId ||
        !comment
    ) {

        alert(
            "Please complete the review."
        );

        return;
    }


    const reviews =
        JSON.parse(
            localStorage.getItem(
                "burgerReviews"
            )
        ) || [];


    reviews.push({

        name,

        orderId,

        rating:
            selectedRating,

        comment,

        date:
            new Date()
                .toLocaleDateString()

    });


    localStorage.setItem(
        "burgerReviews",
        JSON.stringify(reviews)
    );


    renderReviews();


    document.getElementById(
        "reviewMessage"
    ).textContent =
        "Review submitted successfully!";


    document.getElementById(
        "reviewMessage"
    ).style.color =
        "#20854b";


    setTimeout(
        closeReview,
        800
    );

}


function renderReviews() {

    const container =
        document.getElementById(
            "reviewsContainer"
        );


    if (!container) return;


    const reviews =
        JSON.parse(
            localStorage.getItem(
                "burgerReviews"
            )
        ) || [];


    document.getElementById(
        "reviewCount"
    ).textContent =
        reviews.length;


    if (!reviews.length) {

        document.getElementById(
            "averageRating"
        ).textContent =
            "0.0";


        document.getElementById(
            "averageStars"
        ).textContent =
            "☆☆☆☆☆";


        container.innerHTML = `
            <div class="empty">
                ⭐
                <h3>
                    No reviews yet
                </h3>
            </div>
        `;


        return;
    }


    const average =
        reviews.reduce(
            (
                total,
                review
            ) =>
                total +
                Number(
                    review.rating
                ),
            0
        ) /
        reviews.length;


    document.getElementById(
        "averageRating"
    ).textContent =
        average.toFixed(1);


    const rounded =
        Math.round(
            average
        );


    document.getElementById(
        "averageStars"
    ).textContent =
        "★".repeat(
            rounded
        ) +
        "☆".repeat(
            5 - rounded
        );


    container.innerHTML =
        reviews
            .slice()
            .reverse()
            .map(
                review => `

                    <div class="review-card">

                        <b>
                            👤 ${review.name}
                        </b>

                        <div class="review-stars">

                            ${
                                "★".repeat(
                                    Number(
                                        review.rating
                                    )
                                )
                            }

                            ${
                                "☆".repeat(
                                    5 -
                                    Number(
                                        review.rating
                                    )
                                )
                            }

                        </div>

                        <p class="review-comment">
                            ${review.comment}
                        </p>

                        <small>
                            ${review.date}
                            ·
                            ${review.orderId}
                        </small>

                    </div>

                `
            )
            .join("");

}


/* =========================================================
   SAVED DATA
========================================================= */

function loadSavedCheckoutInfo() {

    const phone =
        localStorage.getItem(
            "burgerPhone"
        );


    if (phone) {

        document.getElementById(
            "customerPhone"
        ).value =
            phone;

    }

}


/* =========================================================
   ADMIN DASHBOARD
========================================================= */

function showAdminDashboard() {

    document.body.innerHTML = `

        <div class="admin-app">

            <aside class="admin-sidebar">

                <div class="admin-logo">
                    🍔 Burger House
                </div>

                <div class="sidebar-title">
                    MAIN MENU
                </div>

                <nav class="admin-nav">

                    <button
                        class="admin-nav-item active"
                        onclick="switchAdminPage('dashboard',this)">

                        <span>📊</span>

                        <div>
                            <strong>Dashboard</strong>
                            <small>Overview</small>
                        </div>

                    </button>


                    <button
                        class="admin-nav-item"
                        onclick="switchAdminPage('orders',this)">

                        <span>📦</span>

                        <div>
                            <strong>Orders</strong>
                            <small>Manage orders</small>
                        </div>

                        <b id="sidebarOrderCount">0</b>

                    </button>


                    <button
                        class="admin-nav-item"
                        onclick="switchAdminPage('inventory',this)">

                        <span>🧾</span>

                        <div>
                            <strong>Inventory</strong>
                            <small>Manage stock</small>
                        </div>

                    </button>


                    <button
                        class="admin-nav-item"
                        onclick="switchAdminPage('users',this)">

                        <span>👥</span>

                        <div>
                            <strong>Users</strong>
                            <small>Customers</small>
                        </div>

                        <b id="sidebarUserCount">0</b>

                    </button>


                    <button
                        class="admin-nav-item"
                        onclick="switchAdminPage('reviews',this)">

                        <span>⭐</span>

                        <div>
                            <strong>Reviews</strong>
                            <small>Feedback</small>
                        </div>

                        <b id="sidebarReviewCount">0</b>

                    </button>

                </nav>


                <div class="admin-sidebar-bottom">

                    <div class="admin-account">

                        <div class="admin-avatar">
                            A
                        </div>

                        <div>
                            <strong>
                                Administrator
                            </strong>

                            <small>
                                Super Admin
                            </small>
                        </div>

                    </div>


                    <button
                        class="admin-logout-btn"
                        onclick="adminLogout()">

                        🚪 Logout

                    </button>

                </div>

            </aside>


            <main class="admin-main">

                <header class="admin-topbar">

                    <div>

                        <span class="admin-breadcrumb">
                            BURGER HOUSE / ADMIN
                        </span>

                        <h1 id="adminPageTitle">
                            Dashboard
                        </h1>

                        <p>
                            Manage your restaurant
                        </p>

                    </div>


                    <div class="admin-topbar-right">

                        <button
                            class="admin-refresh-btn"
                            onclick="refreshAdminDashboard()">
                            🔄
                        </button>


                        <button
                            class="admin-notification"
                            onclick="showPendingOrders()">
                            🔔
                            <span id="notificationBadge">
                                0
                            </span>
                        </button>


                        <div class="admin-date-box">

                            📅

                            <span id="adminCurrentDate">
                                —
                            </span>

                        </div>

                    </div>

                </header>


                <!-- DASHBOARD -->

                <section
                    id="adminPage-dashboard"
                    class="admin-page active">

                    <div class="dashboard-welcome">

                        <div>

                            <span>
                                WELCOME BACK 👋
                            </span>

                            <h2>
                                Good day, Administrator!
                            </h2>

                            <p>
                                Here's what's happening
                                in Burger House today.
                            </p>

                        </div>

                        <div class="welcome-burger">
                            🍔
                        </div>

                    </div>


                    <div class="dashboard-stats">

                        <div class="dashboard-stat-card">

                            <div class="dashboard-stat-icon orange">
                                📦
                            </div>

                            <div>

                                <span>Total Orders</span>

                                <strong id="dashboardOrders">
                                    0
                                </strong>

                                <small>
                                    All orders
                                </small>

                            </div>

                        </div>


                        <div class="dashboard-stat-card">

                            <div class="dashboard-stat-icon green">
                                💰
                            </div>

                            <div>

                                <span>Total Sales</span>

                                <strong id="dashboardSales">
                                    ₱0.00
                                </strong>

                                <small>
                                    Overall revenue
                                </small>

                            </div>

                        </div>


                        <div class="dashboard-stat-card">

                            <div class="dashboard-stat-icon blue">
                                👥
                            </div>

                            <div>

                                <span>Registered Users</span>

                                <strong id="dashboardUsers">
                                    0
                                </strong>

                                <small>
                                    Customers
                                </small>

                            </div>

                        </div>


                        <div class="dashboard-stat-card">

                            <div class="dashboard-stat-icon yellow">
                                ⭐
                            </div>

                            <div>

                                <span>Average Rating</span>

                                <strong id="dashboardRating">
                                    0.0
                                </strong>

                                <small>
                                    Customer reviews
                                </small>

                            </div>

                        </div>

                    </div>


                    <div class="dashboard-grid">

                        <div class="admin-panel">

                            <div class="panel-heading">

                                <div>

                                    <h3>
                                        📈 Sales Overview
                                    </h3>

                                    <p>
                                        Order activity
                                    </p>

                                </div>

                                <span class="live-label">
                                    ● LIVE
                                </span>

                            </div>

                            <div
                                id="salesChart"
                                class="sales-chart">
                            </div>

                            <div class="chart-labels">
                                <span>Mon</span>
                                <span>Tue</span>
                                <span>Wed</span>
                                <span>Thu</span>
                                <span>Fri</span>
                                <span>Sat</span>
                                <span>Sun</span>
                            </div>

                        </div>


                        <div class="admin-panel">

                            <div class="panel-heading">

                                <div>

                                    <h3>
                                        📦 Order Status
                                    </h3>

                                    <p>
                                        Current status
                                    </p>

                                </div>

                            </div>

                            <div
                                id="orderStatusSummary">
                            </div>

                        </div>

                    </div>


                    <div class="admin-panel">

                        <div class="panel-heading">

                            <div>

                                <h3>
                                    📦 Recent Orders
                                </h3>

                                <p>
                                    Latest customer orders
                                </p>

                            </div>

                            <button
                                class="panel-action"
                                onclick="switchAdminPage('orders')">
                                View All →
                            </button>

                        </div>

                        <div id="dashboardRecentOrders">
                        </div>

                    </div>


                    <div class="admin-panel">

                        <div class="panel-heading">

                            <div>

                                <h3>
                                    ⚠️ Inventory Alerts
                                </h3>

                                <p>
                                    Products that need attention
                                </p>

                            </div>

                            <button
                                class="panel-action"
                                onclick="switchAdminPage('inventory')">
                                Manage →
                            </button>

                        </div>

                        <div id="dashboardLowStock">
                        </div>

                    </div>

                </section>


                <!-- ORDERS -->

                <section
                    id="adminPage-orders"
                    class="admin-page">

                    <div class="page-heading">

                        <div>

                            <span>
                                ORDER MANAGEMENT
                            </span>

                            <h2>
                                Customer Orders
                            </h2>

                            <p>
                                Manage all customer orders.
                            </p>

                        </div>

                    </div>


                    <div class="admin-panel">

                        <div class="order-tools">

                            <input
                                id="adminOrderSearch"
                                placeholder="🔎 Search order or customer..."
                                oninput="renderAdminOrdersPage()">

                            <select
                                id="adminOrderFilter"
                                onchange="renderAdminOrdersPage()">

                                <option value="all">
                                    All Status
                                </option>

                                <option value="Pending">
                                    Pending
                                </option>

                                <option value="Preparing">
                                    Preparing
                                </option>

                                <option value="Out for Delivery">
                                    Out for Delivery
                                </option>

                                <option value="Delivered">
                                    Delivered
                                </option>

                            </select>

                        </div>

                        <div id="adminOrdersTable">
                        </div>

                    </div>

                </section>


                <!-- INVENTORY -->

                <section
                    id="adminPage-inventory"
                    class="admin-page">

                    <div class="page-heading">

                        <div>

                            <span>
                                PRODUCT MANAGEMENT
                            </span>

                            <h2>
                                Inventory
                            </h2>

                            <p>
                                Manage food stock.
                            </p>

                        </div>

                        <button
                            class="primary-admin-btn"
                            onclick="addInventoryProduct()">

                            ＋ Add Product

                        </button>

                    </div>


                    <div class="inventory-summary">

                        <div>

                            <span>
                                Total Products
                            </span>

                            <strong id="inventoryProductsCount">
                                0
                            </strong>

                        </div>


                        <div>

                            <span>
                                Total Stock
                            </span>

                            <strong id="inventoryTotalStock">
                                0
                            </strong>

                        </div>


                        <div>

                            <span>
                                Low Stock
                            </span>

                            <strong id="inventoryLowStock">
                                0
                            </strong>

                        </div>


                        <div>

                            <span>
                                Out of Stock
                            </span>

                            <strong id="inventoryOutStock">
                                0
                            </strong>

                        </div>

                    </div>


                    <div
                        id="adminInventoryGrid"
                        class="inventory-admin-grid">
                    </div>

                </section>


                <!-- USERS -->

                <section
                    id="adminPage-users"
                    class="admin-page">

                    <div class="page-heading">

                        <div>

                            <span>
                                CUSTOMER MANAGEMENT
                            </span>

                            <h2>
                                Registered Users
                            </h2>

                            <p>
                                View all customers.
                            </p>

                        </div>

                    </div>


                    <div class="user-overview-card">

                        <div class="user-overview-icon">
                            👥
                        </div>

                        <div>

                            <span>
                                Total Registered Users
                            </span>

                            <strong id="usersPageCount">
                                0
                            </strong>

                        </div>

                    </div>


                    <div class="admin-panel">

                        <div class="order-tools">

                            <input
                                id="adminUserSearch"
                                placeholder="🔎 Search user..."
                                oninput="renderAdminUsersPage()">

                        </div>

                        <div id="adminUsersTable">
                        </div>

                    </div>

                </section>


                <!-- REVIEWS -->

                <section
                    id="adminPage-reviews"
                    class="admin-page">

                    <div class="page-heading">

                        <div>

                            <span>
                                CUSTOMER FEEDBACK
                            </span>

                            <h2>
                                Reviews & Ratings
                            </h2>

                            <p>
                                View customer reviews.
                            </p>

                        </div>

                    </div>


                    <div class="review-summary-grid">

                        <div>

                            <strong id="reviewAverage">
                                0.0
                            </strong>

                            <span>
                                Average Rating
                            </span>

                        </div>


                        <div>

                            <strong id="reviewFiveStars">
                                0
                            </strong>

                            <span>
                                5-Star Reviews
                            </span>

                        </div>


                        <div>

                            <strong id="reviewTotal">
                                0
                            </strong>

                            <span>
                                Total Reviews
                            </span>

                        </div>

                    </div>


                    <div
                        id="adminReviewsGrid"
                        class="admin-reviews-grid">
                    </div>

                </section>

            </main>

        </div>


        <div id="adminOrderModal"
             class="admin-order-modal">

            <div class="order-modal-box">

                <button
                    class="order-modal-close"
                    onclick="closeAdminOrderModal()">
                    ×
                </button>

                <div id="adminOrderDetails">
                </div>

            </div>

        </div>
    `;


    loadAdminDashboard();

}


/* =========================================================
   ADMIN NAVIGATION
========================================================= */

function switchAdminPage(
    page,
    button = null
) {

    document
        .querySelectorAll(
            ".admin-page"
        )
        .forEach(
            pageElement =>
                pageElement.classList.remove(
                    "active"
                )
        );


    const target =
        document.getElementById(
            "adminPage-" + page
        );


    if (target) {

        target.classList.add(
            "active"
        );

    }


    document
        .querySelectorAll(
            ".admin-nav-item"
        )
        .forEach(
            item =>
                item.classList.remove(
                    "active"
                )
        );


    if (button) {

        button.classList.add(
            "active"
        );

    }


    const titles = {

        dashboard: [
            "Dashboard",
            "Manage your restaurant"
        ],

        orders: [
            "Customer Orders",
            "Order management"
        ],

        inventory: [
            "Inventory",
            "Stock management"
        ],

        users: [
            "Registered Users",
            "Customer management"
        ],

        reviews: [
            "Reviews & Ratings",
            "Customer feedback"
        ]

    };


    if (titles[page]) {

        document.getElementById(
            "adminPageTitle"
        ).textContent =
            titles[page][0];

        document.getElementById(
            "adminPageSubtitle"
        ).textContent =
            titles[page][1];

    }


    if (
        page ===
        "orders"
    ) {

        renderAdminOrdersPage();

    }


    if (
        page ===
        "inventory"
    ) {

        renderAdminInventory();

    }


    if (
        page ===
        "users"
    ) {

        renderAdminUsersPage();

    }


    if (
        page ===
        "reviews"
    ) {

        renderAdminReviews();

    }

}


/* =========================================================
   LOAD ADMIN
========================================================= */

function loadAdminDashboard() {

    renderDashboardStats();

    renderDashboardOrders();

    renderOrderStatus();

    renderSalesChart();

    renderLowStock();

    renderAdminOrdersPage();

    renderAdminInventory();

    renderAdminUsersPage();

    renderAdminReviews();

    updateAdminDate();

}


/* =========================================================
   DASHBOARD STATS
========================================================= */

function renderDashboardStats() {

    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const users =
        JSON.parse(
            localStorage.getItem(
                "burgerUsers"
            )
        ) || [];


    const reviews =
        JSON.parse(
            localStorage.getItem(
                "burgerReviews"
            )
        ) || [];


    const sales =
        orders.reduce(
            (
                total,
                order
            ) =>
                total +
                Number(
                    order.total || 0
                ),
            0
        );


    const averageRating =
        reviews.length
            ? reviews.reduce(
                (
                    sum,
                    review
                ) =>
                    sum +
                    Number(
                        review.rating ||
                        0
                    ),
                0
            ) /
            reviews.length
            : 0;


    document.getElementById(
        "dashboardOrders"
    ).textContent =
        orders.length;


    document.getElementById(
        "dashboardSales"
    ).textContent =
        "₱" +
        sales.toLocaleString(
            "en-PH",
            {
                minimumFractionDigits:2
            }
        );


    document.getElementById(
        "dashboardUsers"
    ).textContent =
        users.length;


    document.getElementById(
        "dashboardRating"
    ).textContent =
        averageRating.toFixed(1);


    document.getElementById(
        "sidebarOrderCount"
    ).textContent =
        orders.length;


    document.getElementById(
        "sidebarUserCount"
    ).textContent =
        users.length;


    document.getElementById(
        "sidebarReviewCount"
    ).textContent =
        reviews.length;


    document.getElementById(
        "notificationBadge"
    ).textContent =
        orders.filter(
            order =>
                !order.status ||
                order.status ===
                "Pending"
        ).length;

}


/* =========================================================
   RECENT ORDERS
========================================================= */

function renderDashboardOrders() {

    const container =
        document.getElementById(
            "dashboardRecentOrders"
        );


    if (!container) return;


    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const recent =
        orders
            .slice()
            .reverse()
            .slice(
                0,
                7
            );


    if (!recent.length) {

        container.innerHTML = `
            <div class="empty">
                📦
                <h3>
                    No orders yet
                </h3>
            </div>
        `;

        return;
    }


    container.innerHTML = `

        <div class="admin-table-wrap">

            <table class="admin-table">

                <thead>

                    <tr>
                        <th>ORDER</th>
                        <th>CUSTOMER</th>
                        <th>TOTAL</th>
                        <th>STATUS</th>
                        <th>ACTION</th>
                    </tr>

                </thead>

                <tbody>

                    ${
                        recent
                        .map(
                            order => `

                                <tr>

                                    <td>
                                        <b>
                                            ${order.id}
                                        </b>
                                    </td>

                                    <td>
                                        ${order.customerName}
                                    </td>

                                    <td>
                                        ₱${Number(
                                            order.total
                                        ).toFixed(2)}
                                    </td>

                                    <td>

                                        <span class="status-badge">
                                            ${
                                                order.status ||
                                                "Pending"
                                            }
                                        </span>

                                    </td>

                                    <td>

                                        <button
                                            class="panel-action"
                                            onclick="showOrderDetails('${order.id}')">

                                            View

                                        </button>

                                    </td>

                                </tr>
                            `
                        )
                        .join("")
                    }

                </tbody>

            </table>

        </div>
    `;

}


/* =========================================================
   ORDER STATUS
========================================================= */

function renderOrderStatus() {

    const container =
        document.getElementById(
            "orderStatusSummary"
        );


    if (!container) return;


    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const statuses = {

        Pending: 0,

        Preparing: 0,

        "Out for Delivery": 0,

        Delivered: 0

    };


    orders.forEach(
        order => {

            const status =
                order.status ||
                "Pending";

            if (
                statuses[
                    status
                ] !== undefined
            ) {

                statuses[
                    status
                ]++;

            }

        }
    );


    container.innerHTML = `

        <div class="status-line">
            <span>
                🟡 Pending
            </span>

            <strong>
                ${statuses.Pending}
            </strong>
        </div>

        <div class="status-line">
            <span>
                🔵 Preparing
            </span>

            <strong>
                ${statuses.Preparing}
            </strong>
        </div>

        <div class="status-line">
            <span>
                🟣 Out for Delivery
            </span>

            <strong>
                ${statuses["Out for Delivery"]}
            </strong>
        </div>

        <div class="status-line">
            <span>
                🟢 Delivered
            </span>

            <strong>
                ${statuses.Delivered}
            </strong>
        </div>
    `;

}


/* =========================================================
   SALES CHART
========================================================= */

function renderSalesChart() {

    const chart =
        document.getElementById(
            "salesChart"
        );


    if (!chart) return;


    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const days = [

        "Mon",
        "Tue",
        "Wed",
        "Thu",
        "Fri",
        "Sat",
        "Sun"

    ];


    const values =
        days.map(
            (
                day,
                index
            ) => {

                const value =
                    orders.reduce(
                        (
                            total,
                            order
                        ) => {

                            return total +
                                (
                                    Number(
                                        order.total ||
                                        0
                                    )
                                    /
                                    (
                                        7
                                    )
                                );

                        },
                        0
                    );


                return Math.max(
                    15,
                    Math.min(
                        100,
                        value / 10
                    )
                );

            }
        );


    chart.innerHTML =
        values
        .map(
            value => `

                <div
                    class="chart-bar"
                    style="
                        height:${value}%;
                    ">
                </div>
            `
        )
        .join("");

}


/* =========================================================
   LOW STOCK
========================================================= */

function getInventory() {

    let inventory =
        JSON.parse(
            localStorage.getItem(
                "burgerInventory"
            )
        );


    if (!Array.isArray(inventory)) {

        inventory =
            menuItems.map(
                (
                    item,
                    index
                ) => ({

                    id:
                        item.id,

                    name:
                        item.name,

                    category:
                        item.category,

                    stock:
                        [
                            24,
                            18,
                            8,
                            35,
                            6,
                            40,
                            22,
                            12
                        ][index] || 10,

                    minimum:
                        10,

                    price:
                        item.price,

                    image:
                        item.image

                })
            );


        localStorage.setItem(
            "burgerInventory",
            JSON.stringify(
                inventory
            )
        );

    }


    return inventory;

}


function renderLowStock() {

    const container =
        document.getElementById(
            "dashboardLowStock"
        );


    if (!container) return;


    const inventory =
        getInventory();


    const low =
        inventory.filter(
            item =>
                Number(
                    item.stock
                ) <=
                Number(
                    item.minimum
                )
        );


    if (!low.length) {

        container.innerHTML = `
            <div class="empty">
                ✅ All products have enough stock.
            </div>
        `;

        return;
    }


    container.innerHTML =
        low.map(
            item => `

                <div class="low-stock">

                    <div class="low-stock-icon">
                        ⚠️
                    </div>

                    <div style="flex:1">

                        <strong>
                            ${item.name}
                        </strong>

                        <small>
                            ${item.stock}
                            piece(s) remaining
                        </small>

                    </div>

                    <b style="color:#e63946">
                        LOW
                    </b>

                </div>

            `
        ).join("");

}


/* =========================================================
   INVENTORY PAGE
========================================================= */

function renderAdminInventory() {

    const container =
        document.getElementById(
            "adminInventoryGrid"
        );


    if (!container) return;


    const inventory =
        getInventory();


    const totalStock =
        inventory.reduce(
            (
                sum,
                item
            ) =>
                sum +
                Number(
                    item.stock
                ),
            0
        );


    const lowStock =
        inventory.filter(
            item =>
                item.stock > 0 &&
                item.stock <=
                item.minimum
        ).length;


    const outStock =
        inventory.filter(
            item =>
                item.stock <= 0
        ).length;


    document.getElementById(
        "inventoryProductsCount"
    ).textContent =
        inventory.length;


    document.getElementById(
        "inventoryTotalStock"
    ).textContent =
        totalStock;


    document.getElementById(
        "inventoryLowStock"
    ).textContent =
        lowStock;


    document.getElementById(
        "inventoryOutStock"
    ).textContent =
        outStock;


    container.innerHTML =
        inventory.map(
            item => {

                const percentage =
                    Math.min(
                        (
                            item.stock /
                            Math.max(
                                item.minimum *
                                3,
                                30
                            )
                        ) * 100,
                        100
                    );


                let state =
                    "stock-good";

                let text =
                    "IN STOCK";


                if (
                    item.stock <=
                    item.minimum &&
                    item.stock > 0
                ) {

                    state =
                        "stock-low";

                    text =
                        "LOW STOCK";

                }


                if (
                    item.stock <=
                    0
                ) {

                    state =
                        "stock-out";

                    text =
                        "OUT OF STOCK";

                }


                return `

                    <div class="inventory-card-admin">

                        <img
                            src="${item.image}"
                            alt="${item.name}"
                        >

                        <div class="inventory-card-content">

                            <h3>
                                ${item.name}
                            </h3>

                            <span class="inventory-category">
                                ${item.category}
                            </span>

                            <div class="inventory-price">
                                ₱${Number(
                                    item.price
                                ).toFixed(2)}
                            </div>


                            <div class="stock-bar">

                                <div
                                    class="stock-fill"
                                    style="
                                        width:${percentage}%;
                                    ">
                                </div>

                            </div>


                            <div class="inventory-stock">

                                <span class="${state}">
                                    ● ${text}
                                </span>


                                <div class="stock-controls">

                                    <button
                                        onclick="
                                            changeInventoryStock(
                                                ${item.id},
                                                -1
                                            )
                                        ">
                                        −
                                    </button>

                                    <span class="stock-number">
                                        ${item.stock}
                                    </span>

                                    <button
                                        onclick="
                                            changeInventoryStock(
                                                ${item.id},
                                                1
                                            )
                                        ">
                                        +
                                    </button>

                                </div>

                            </div>

                        </div>

                    </div>

                `;

            }
        ).join("");

}


/* =========================================================
   STOCK
========================================================= */

function changeInventoryStock(
    id,
    amount
) {

    const inventory =
        getInventory();


    const item =
        inventory.find(
            product =>
                product.id === id
        );


    if (!item) return;


    item.stock =
        Math.max(
            0,
            Number(
                item.stock
            ) +
            amount
        );


    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(
            inventory
        )
    );


    loadAdminDashboard();

}


function addInventoryProduct() {

    const name =
        prompt(
            "Product name:"
        );


    if (!name) return;


    const category =
        prompt(
            "Category:"
        );


    if (!category) return;


    const price =
        Number(
            prompt(
                "Price:",
                "99"
            )
        );


    if (
        !Number.isFinite(
            price
        ) ||
        price < 0
    ) {

        alert(
            "Invalid price."
        );

        return;
    }


    const stock =
        Number(
            prompt(
                "Initial stock:",
                "10"
            )
        );


    if (
        !Number.isInteger(
            stock
        ) ||
        stock < 0
    ) {

        alert(
            "Invalid stock."
        );

        return;
    }


    const inventory =
        getInventory();


    const id =
        Date.now();


    inventory.push({

        id,

        name,

        category,

        price,

        stock,

        minimum:
            10,

        image:
            "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"

    });


    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(
            inventory
        )
    );


    loadAdminDashboard();

}


/* =========================================================
   ORDERS PAGE
========================================================= */

function renderAdminOrdersPage() {

    const container =
        document.getElementById(
            "adminOrdersTable"
        );


    if (!container) return;


    let orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const search =
        document.getElementById(
            "adminOrderSearch"
        )?.value
        ?.toLowerCase()
        ?.trim();


    const filter =
        document.getElementById(
            "adminOrderFilter"
        )?.value ||
        "all";


    if (search) {

        orders =
            orders.filter(
                order =>
                    String(
                        order.id
                    )
                    .toLowerCase()
                    .includes(
                        search
                    )

                    ||

                    String(
                        order.customerName
                    )
                    .toLowerCase()
                    .includes(
                        search
                    )
            );

    }


    if (
        filter !==
        "all"
    ) {

        orders =
            orders.filter(
                order =>
                    (
                        order.status ||
                        "Pending"
                    ) ===
                    filter
            );

    }


    if (!orders.length) {

        container.innerHTML = `
            <div class="empty">
                📦
                <h3>
                    No Orders Found
                </h3>
            </div>
        `;

        return;
    }


    container.innerHTML = `

        <div class="admin-table-wrap">

            <table class="admin-table">

                <thead>

                    <tr>

                        <th>Order</th>
                        <th>Customer</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Rider</th>
                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                    ${
                        orders
                        .slice()
                        .reverse()
                        .map(
                            order => `

                                <tr>

                                    <td>

                                        <b>
                                            ${order.id}
                                        </b>

                                        <small style="
                                            display:block;
                                            color:#aaa;
                                            margin-top:3px;
                                        ">
                                            ${order.date}
                                        </small>

                                    </td>


                                    <td>
                                        ${order.customerName}
                                    </td>


                                    <td>
                                        <b>
                                            ₱${Number(
                                                order.total
                                            ).toFixed(2)}
                                        </b>
                                    </td>


                                    <td>

                                        <select
                                            onchange="
                                                updateOrderStatus(
                                                    '${order.id}',
                                                    this.value
                                                )
                                            "
                                        >

                                            ${createStatusOptions(
                                                order.status
                                            )}

                                        </select>

                                    </td>


                                    <td>
                                        🏍️ ${order.rider}
                                    </td>


                                    <td>

                                        <button
                                            class="panel-action"
                                            onclick="
                                                showOrderDetails(
                                                    '${order.id}'
                                                )
                                            ">
                                            View
                                        </button>

                                    </td>

                                </tr>

                            `
                        )
                        .join("")
                    }

                </tbody>

            </table>

        </div>
    `;

}


function createStatusOptions(
    current
) {

    const statuses = [

        "Pending",

        "Preparing",

        "Out for Delivery",

        "Delivered"

    ];


    return statuses
        .map(
            status => `

                <option
                    value="${status}"
                    ${
                        (
                            current ||
                            "Pending"
                        ) === status
                            ? "selected"
                            : ""
                    }>
                    ${status}
                </option>
            `
        )
        .join("");

}


/* =========================================================
   UPDATE ORDER
========================================================= */

function updateOrderStatus(
    orderId,
    newStatus
) {

    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const order =
        orders.find(
            item =>
                item.id ===
                orderId
        );


    if (!order) return;


    order.status =
        newStatus;


    localStorage.setItem(
        "burgerOrders",
        JSON.stringify(
            orders
        )
    );


    loadAdminDashboard();

}


/* =========================================================
   USERS
========================================================= */

function renderAdminUsersPage() {

    const container =
        document.getElementById(
            "adminUsersTable"
        );


    if (!container) return;


    let users =
        JSON.parse(
            localStorage.getItem(
                "burgerUsers"
            )
        ) || [];


    const search =
        document.getElementById(
            "adminUserSearch"
        )?.value
        ?.toLowerCase()
        ?.trim();


    if (search) {

        users =
            users.filter(
                user =>
                    String(
                        user.name
                    )
                    .toLowerCase()
                    .includes(
                        search
                    )

                    ||

                    String(
                        user.email
                    )
                    .toLowerCase()
                    .includes(
                        search
                    )
            );

    }


    document.getElementById(
        "usersPageCount"
    ).textContent =
        users.length;


    if (!users.length) {

        container.innerHTML = `
            <div class="empty">
                👥 No users found.
            </div>
        `;

        return;
    }


    container.innerHTML = `

        <div class="admin-table-wrap">

            <table class="admin-table">

                <thead>

                    <tr>

                        <th>#</th>
                        <th>User</th>
                        <th>Email</th>
                        <th>Status</th>

                    </tr>

                </thead>

                <tbody>

                    ${
                        users
                        .map(
                            (
                                user,
                                index
                            ) => `

                                <tr>

                                    <td>
                                        ${index + 1}
                                    </td>

                                    <td>
                                        👤
                                        ${user.name}
                                    </td>

                                    <td>
                                        ${user.email}
                                    </td>

                                    <td>

                                        <span
                                            style="
                                                color:#198754;
                                                font-weight:bold;
                                            ">

                                            ● Active

                                        </span>

                                    </td>

                                </tr>

                            `
                        )
                        .join("")
                    }

                </tbody>

            </table>

        </div>
    `;

}


/* =========================================================
   REVIEWS
========================================================= */

function renderAdminReviews() {

    const container =
        document.getElementById(
            "adminReviewsGrid"
        );


    if (!container) return;


    const reviews =
        JSON.parse(
            localStorage.getItem(
                "burgerReviews"
            )
        ) || [];


    const average =
        reviews.length
            ? reviews.reduce(
                (
                    sum,
                    review
                ) =>
                    sum +
                    Number(
                        review.rating
                    ),
                0
            ) /
            reviews.length
            : 0;


    const five =
        reviews.filter(
            review =>
                Number(
                    review.rating
                ) === 5
        ).length;


    document.getElementById(
        "reviewAverage"
    ).textContent =
        average.toFixed(1);


    document.getElementById(
        "reviewFiveStars"
    ).textContent =
        five;


    document.getElementById(
        "reviewTotal"
    ).textContent =
        reviews.length;


    if (!reviews.length) {

        container.innerHTML = `
            <div class="admin-panel empty">
                ⭐ No reviews yet.
            </div>
        `;

        return;
    }


    container.innerHTML =
        reviews
        .slice()
        .reverse()
        .map(
            review => `

                <div class="admin-review-card">

                    <div class="review-user">

                        <div style="
                            display:flex;
                            align-items:center;
                            gap:9px;
                        ">

                            <div class="review-avatar">
                                👤
                            </div>

                            <div>

                                <strong>
                                    ${review.name}
                                </strong>

                                <small style="
                                    display:block;
                                    color:#999;
                                ">
                                    ${review.date}
                                </small>

                            </div>

                        </div>


                        <div class="review-stars">

                            ${
                                "★".repeat(
                                    Number(
                                        review.rating
                                    )
                                )
                            }

                            ${
                                "☆".repeat(
                                    5 -
                                    Number(
                                        review.rating
                                    )
                                )
                            }

                        </div>

                    </div>


                    <p>
                        ${review.comment}
                    </p>


                    <small>
                        Order:
                        ${review.orderId}
                    </small>

                </div>

            `
        )
        .join("");

}


/* =========================================================
   ORDER DETAILS
========================================================= */

function showOrderDetails(
    orderId
) {

    const orders =
        JSON.parse(
            localStorage.getItem(
                "burgerOrders"
            )
        ) || [];


    const order =
        orders.find(
            item =>
                item.id ===
                orderId
        );


    if (!order) return;


    const container =
        document.getElementById(
            "adminOrderDetails"
        );


    container.innerHTML = `

        <h2>
            📦 Order ${order.id}
        </h2>


        <div class="order-detail-row">

            <span>
                Customer
            </span>

            <strong>
                ${order.customerName}
            </strong>

        </div>


        <div class="order-detail-row">

            <span>
                Phone
            </span>

            <strong>
                ${order.phone}
            </strong>

        </div>


        <div class="order-detail-row">

            <span>
                Rider
            </span>

            <strong>
                🏍️ ${order.rider}
            </strong>

        </div>


        <div class="order-detail-row">

            <span>
                Location
            </span>

            <strong>
                ${order.barangay},
                ${order.municipality}
            </strong>

        </div>


        <div class="order-detail-row">

            <span>
                Status
            </span>

            <strong>
                ${order.status}
            </strong>

        </div>


        <div class="order-items-box">

            <h4>
                Ordered Items
            </h4>

            ${
                order.items
                .map(
                    item => `

                        <div class="order-detail-row">

                            <span>
                                ${item.name}
                                ×${item.quantity}
                            </span>

                            <strong>
                                ₱${(
                                    item.price *
                                    item.quantity
                                ).toFixed(2)}
                            </strong>

                        </div>

                    `
                )
                .join("")
            }

            <div
                class="order-detail-row"
                style="
                    border-top:2px solid #222;
                    margin-top:10px;
                "
            >

                <strong>
                    TOTAL
                </strong>

                <strong style="color:#e63946">

                    ₱${Number(
                        order.total
                    ).toFixed(2)}

                </strong>

            </div>

        </div>

    `;


    document.getElementById(
        "adminOrderModal"
    ).classList.add(
        "show"
    );

}


function closeAdminOrderModal() {

    document.getElementById(
        "adminOrderModal"
    ).classList.remove(
        "show"
    );

}


/* =========================================================
   PENDING ORDERS
========================================================= */

function showPendingOrders() {

    switchAdminPage(
        "orders"
    );

}


/* =========================================================
   REFRESH
========================================================= */

function refreshAdminDashboard() {

    loadAdminDashboard();

    const button =
        document.querySelector(
            ".admin-refresh-btn"
        );


    if (button) {

        button.textContent =
            "✅";

        setTimeout(
            function () {

                button.textContent =
                    "🔄";

            },
            700
        );

    }

}


/* =========================================================
   DATE
========================================================= */

function updateAdminDate() {

    const element =
        document.getElementById(
            "adminCurrentDate"
        );


    if (!element) return;


    element.textContent =
        new Date().toLocaleDateString(
            "en-PH",
            {
                year:
                    "numeric",

                month:
                    "long",

                day:
                    "numeric"

            }
        );

}


/* =========================================================
   ADMIN LOGOUT
========================================================= */

function adminLogout() {

    if (
        !confirm(
            "Are you sure you want to logout?"
        )
    ) {

        return;

    }


    localStorage.removeItem(
        "adminLoggedIn"
    );


    location.reload();

}


/* =========================================================
   CLOSE MODALS
========================================================= */

window.addEventListener(
    "click",
    function (event) {

        document
            .querySelectorAll(
                ".modal"
            )
            .forEach(
                modal => {

                    if (
                        event.target ===
                        modal
                    ) {

                        modal.style.display =
                            "none";

                    }

                }
            );


        const settings =
            document.getElementById(
                "settingsMenu"
            );


        const settingsButton =
            document.querySelector(
                ".settings-btn"
            );


        if (
            settings &&
            settingsButton &&
            !settings.contains(
                event.target
            ) &&
            !settingsButton.contains(
                event.target
            )
        ) {

            settings.classList.remove(
                "show"
            );

        }

    }
);