// ==========================================
// BURGER HOUSE INVENTORY
// Temporary localStorage database
// ==========================================


// ==========================================
// DEFAULT INVENTORY
// ==========================================

const defaultInventory = [

    {
        id: 1,

        name: "Classic Burger",

        category: "Burger",

        price: 129,

        stock: 50,

        image:
            "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 2,

        name: "Cheese Burger",

        category: "Burger",

        price: 149,

        stock: 40,

        image:
            "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 3,

        name: "Bacon Burger",

        category: "Burger",

        price: 179,

        stock: 35,

        image:
            "https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 4,

        name: "French Fries",

        category: "Fries",

        price: 79,

        stock: 60,

        image:
            "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 5,

        name: "Cheese Fries",

        category: "Fries",

        price: 99,

        stock: 30,

        image:
            "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 6,

        name: "Cola",

        category: "Drink",

        price: 49,

        stock: 80,

        image:
            "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 7,

        name: "Iced Tea",

        category: "Drink",

        price: 55,

        stock: 70,

        image:
            "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80"
    },

    {
        id: 8,

        name: "Burger Combo",

        category: "Combo",

        price: 229,

        stock: 25,

        image:
            "https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=600&q=80"
    }

];


// ==========================================
// LOAD INVENTORY
// ==========================================

let inventory =
    JSON.parse(
        localStorage.getItem("burgerInventory")
    );


// ==========================================
// IF EMPTY, CREATE DEFAULT INVENTORY
// ==========================================

if (!inventory || inventory.length === 0) {

    inventory =
        JSON.parse(
            JSON.stringify(defaultInventory)
        );

    saveInventory();
}


// ==========================================
// SAVE INVENTORY
// ==========================================

function saveInventory() {

    localStorage.setItem(
        "burgerInventory",
        JSON.stringify(inventory)
    );

}


// ==========================================
// DISPLAY INVENTORY
// ==========================================

function displayInventory() {

    const container =
        document.getElementById(
            "inventoryContainer"
        );


    if (inventory.length === 0) {

        container.innerHTML = `

            <div class="empty">

                <h3>
                    No products in inventory.
                </h3>

                <p>
                    Click "Add Product" to create one.
                </p>

            </div>

        `;

        return;
    }


    let html = `

        <table class="inventory-table">

            <thead>

                <tr>

                    <th>Image</th>

                    <th>Product</th>

                    <th>Category</th>

                    <th>Price</th>

                    <th>Stock</th>

                    <th>Status</th>

                    <th>Actions</th>

                </tr>

            </thead>

            <tbody>

    `;


    inventory.forEach(product => {

        let status = "";
        let statusClass = "";


        if (product.stock <= 0) {

            status = "Out of Stock";
            statusClass = "out-stock";

        } else if (product.stock <= 10) {

            status = "Low Stock";
            statusClass = "low-stock";

        } else {

            status = "In Stock";
            statusClass = "in-stock";

        }


        html += `

            <tr>

                <td>

                    <img
                        class="product-image"
                        src="${product.image}"
                        alt="${product.name}"
                    >

                </td>


                <td>

                    <strong>
                        ${product.name}
                    </strong>

                </td>


                <td>
                    ${product.category}
                </td>


                <td>

                    ₱

                    <input
                        class="price-input"
                        type="number"
                        min="0"
                        value="${product.price}"
                        id="price-${product.id}"
                    >

                </td>


                <td>

                    <input
                        class="stock-input"
                        type="number"
                        min="0"
                        value="${product.stock}"
                        id="stock-${product.id}"
                    >

                </td>


                <td>

                    <span
                        class="status ${statusClass}">
                        ${status}
                    </span>

                </td>


                <td>

                    <button
                        class="action-btn save-btn"
                        onclick="saveProduct(${product.id})">
                        Save
                    </button>

                    <button
                        class="action-btn delete-btn"
                        onclick="deleteProduct(${product.id})">
                        Delete
                    </button>

                </td>

            </tr>

        `;

    });


    html += `

            </tbody>

        </table>

    `;


    container.innerHTML = html;

}


// ==========================================
// SAVE PRODUCT
// ==========================================

function saveProduct(id) {

    const product =
        inventory.find(
            item => item.id === id
        );


    if (!product) return;


    const price =
        Number(
            document.getElementById(
                `price-${id}`
            ).value
        );


    const stock =
        Number(
            document.getElementById(
                `stock-${id}`
            ).value
        );


    if (price < 0 || stock < 0) {

        alert(
            "Price and stock cannot be negative."
        );

        return;
    }


    product.price = price;

    product.stock = stock;


    saveInventory();

    displayInventory();


    alert(
        `${product.name} updated successfully!`
    );

}


// ==========================================
// DELETE PRODUCT
// ==========================================

function deleteProduct(id) {

    const product =
        inventory.find(
            item => item.id === id
        );


    if (!product) return;


    const confirmDelete =
        confirm(
            `Delete "${product.name}" from inventory?`
        );


    if (!confirmDelete) return;


    inventory =
        inventory.filter(
            item => item.id !== id
        );


    saveInventory();

    displayInventory();

}


// ==========================================
// OPEN ADD PRODUCT
// ==========================================

function openAddProduct() {

    document.getElementById(
        "productModal"
    ).style.display = "flex";

}


// ==========================================
// CLOSE ADD PRODUCT
// ==========================================

function closeProductModal() {

    document.getElementById(
        "productModal"
    ).style.display = "none";

}


// ==========================================
// ADD PRODUCT
// ==========================================

function addProduct() {

    const name =
        document.getElementById(
            "productName"
        ).value.trim();


    const category =
        document.getElementById(
            "productCategory"
        ).value;


    const price =
        Number(
            document.getElementById(
                "productPrice"
            ).value
        );


    const stock =
        Number(
            document.getElementById(
                "productStock"
            ).value
        );


    const image =
        document.getElementById(
            "productImage"
        ).value.trim();


    if (!name) {

        alert(
            "Please enter product name."
        );

        return;
    }


    if (price < 0 || stock < 0) {

        alert(
            "Price and stock cannot be negative."
        );

        return;
    }


    const newProduct = {

        id:
            Date.now(),

        name:
            name,

        category:
            category,

        price:
            price,

        stock:
            stock,

        image:
            image ||
            "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"

    };


    inventory.push(
        newProduct
    );


    saveInventory();

    displayInventory();

    closeProductModal();


    // CLEAR FORM

    document.getElementById(
        "productName"
    ).value = "";


    document.getElementById(
        "productPrice"
    ).value = "";


    document.getElementById(
        "productStock"
    ).value = "";


    document.getElementById(
        "productImage"
    ).value = "";


    alert(
        `${name} added to inventory!`
    );

}


// ==========================================
// CLOSE MODAL WHEN CLICKING OUTSIDE
// ==========================================

window.addEventListener(
    "click",
    function(event) {

        const modal =
            document.getElementById(
                "productModal"
            );


        if (event.target === modal) {

            closeProductModal();

        }

    }
);


// ==========================================
// START
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        displayInventory();

    }
);