-- TORRELIZA / BURGER HOUSE DATABASE
-- SQLite database script
-- Open this file in VS Code or run it with SQLite.

PRAGMA foreign_keys = ON;

BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK(role IN ('customer','admin','staff')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price REAL NOT NULL,
  category TEXT NOT NULL,
  image TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER UNIQUE NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  minimum INTEGER NOT NULL DEFAULT 10,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  customer_name TEXT NOT NULL,
  customer_email TEXT,
  total REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending',
  payment_method TEXT DEFAULT 'Cash',
  delivery_address TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  product_id INTEGER,
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  price REAL NOT NULL,
  subtotal REAL NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  customer_name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Published',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Demo accounts already used by the backend.
-- Passwords are stored as bcrypt hashes, never plain text.
INSERT OR IGNORE INTO users(id,name,email,password_hash,role) VALUES
(1,'Administrator','admin@burgerhouse.com','$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','admin');

INSERT OR IGNORE INTO users(id,name,email,password_hash,role) VALUES
(2,'Burger House Staff','staff@burgerhouse.com','$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','staff');

INSERT OR IGNORE INTO users(id,name,email,password_hash,role) VALUES
(3,'Demo Customer','customer@burgerhouse.com','$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','customer');

INSERT OR IGNORE INTO products(id,name,price,category,image) VALUES
(1,'Classic Burger',99,'Burger','https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=80'),
(2,'Cheese Burger',119,'Burger','https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=700&q=80'),
(3,'Bacon Burger',139,'Burger','https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=700&q=80'),
(4,'French Fries',59,'Side Dish','https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80'),
(5,'Cheese Fries',79,'Side Dish','https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=700&q=80'),
(6,'Soft Drink',45,'Drink','https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=700&q=80'),
(7,'Iced Tea',50,'Drink','https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=80'),
(8,'Burger Combo',169,'Combo','https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=80');

INSERT OR IGNORE INTO inventory(id,product_id,stock,minimum) VALUES
(1,1,25,10),
(2,2,18,10),
(3,3,7,10),
(4,4,30,10),
(5,5,5,10),
(6,6,40,10),
(7,7,25,10),
(8,8,12,10);

COMMIT;

-- Useful checks:
-- SELECT * FROM users;
-- SELECT * FROM products;
-- SELECT * FROM inventory;
-- SELECT * FROM orders;
-- SELECT * FROM order_items;
-- SELECT * FROM reviews;
