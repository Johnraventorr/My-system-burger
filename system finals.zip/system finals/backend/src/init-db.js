const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dbDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dbDir, { recursive: true });
const db = new sqlite3.Database(path.join(dbDir, 'burger-house.sqlite'));

const products = [
  ['Classic Burger',99,'Burger','https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=80'],
  ['Cheese Burger',119,'Burger','https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=700&q=80'],
  ['Bacon Burger',139,'Burger','https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=700&q=80'],
  ['French Fries',59,'Side Dish','https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80'],
  ['Cheese Fries',79,'Side Dish','https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=700&q=80'],
  ['Soft Drink',45,'Drink','https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=700&q=80'],
  ['Iced Tea',50,'Drink','https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=80'],
  ['Burger Combo',169,'Combo','https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=80']
];
const stock = [25,18,7,30,5,40,25,12];

function run(sql, params=[]) { return new Promise((resolve,reject)=>db.run(sql,params,function(err){err?reject(err):resolve(this)})); }
function all(sql, params=[]) { return new Promise((resolve,reject)=>db.all(sql,params,(e,r)=>e?reject(e):resolve(r))); }

(async()=>{
  try {
    await run(`PRAGMA foreign_keys = ON`);
    await run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer' CHECK(role IN ('customer','admin','staff')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
    await run(`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL, category TEXT NOT NULL, image TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
    await run(`CREATE TABLE IF NOT EXISTS inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER UNIQUE NOT NULL, stock INTEGER NOT NULL DEFAULT 0, minimum INTEGER NOT NULL DEFAULT 10, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE)`);
    await run(`CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, customer_name TEXT NOT NULL, customer_email TEXT, total REAL NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', payment_method TEXT DEFAULT 'Cash', delivery_address TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)`);
    await run(`CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER, product_name TEXT NOT NULL, quantity INTEGER NOT NULL, price REAL NOT NULL, subtotal REAL NOT NULL, FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL)`);
    await run(`CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, customer_name TEXT NOT NULL, rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), comment TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Published', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)`);

    const adminHash = await bcrypt.hash('admin123', 10);
    const staffHash = await bcrypt.hash('staff123', 10);
    const customerHash = await bcrypt.hash('customer123', 10);
    await run(`INSERT OR IGNORE INTO users(name,email,password_hash,role) VALUES (?,?,?,?)`, ['Administrator','admin@burgerhouse.com',adminHash,'admin']);
    await run(`INSERT OR IGNORE INTO users(name,email,password_hash,role) VALUES (?,?,?,?)`, ['Burger House Staff','staff@burgerhouse.com',staffHash,'staff']);
    await run(`INSERT OR IGNORE INTO users(name,email,password_hash,role) VALUES (?,?,?,?)`, ['Demo Customer','customer@burgerhouse.com',customerHash,'customer']);

    for (const p of products) {
      await run(`INSERT OR IGNORE INTO products(name,price,category,image) VALUES (?,?,?,?)`, p);
    }
    const rows = await all(`SELECT id FROM products ORDER BY id`);
    for (let i=0;i<rows.length;i++) await run(`INSERT OR IGNORE INTO inventory(product_id,stock,minimum) VALUES (?,?,10)`, [rows[i].id, stock[i] ?? 10]);

    console.log('Database ready: data/burger-house.sqlite');
    console.log('Admin: admin@burgerhouse.com / admin123');
    console.log('Staff: staff@burgerhouse.com / staff123');
    console.log('Customer: customer@burgerhouse.com / customer123');
  } catch(e) { console.error(e); process.exitCode=1; }
  finally { db.close(); }
})();
