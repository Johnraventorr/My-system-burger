const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'burger-house-development-secret';
const dbPath = path.join(__dirname, '..', 'data', 'burger-house.sqlite');
if (!fs.existsSync(dbPath)) require('./init-db');
const db = new sqlite3.Database(dbPath);
db.run('PRAGMA foreign_keys = ON');
const app = express();
app.use(cors());
app.use(express.json());

const run=(s,p=[])=>new Promise((res,rej)=>db.run(s,p,function(e){e?rej(e):res(this)}));
const get=(s,p=[])=>new Promise((res,rej)=>db.get(s,p,(e,r)=>e?rej(e):res(r)));
const all=(s,p=[])=>new Promise((res,rej)=>db.all(s,p,(e,r)=>e?rej(e):res(r)));
const tokenFor=u=>jwt.sign({id:u.id,name:u.name,email:u.email,role:u.role},JWT_SECRET,{expiresIn:'7d'});
function auth(req,res,next){ const h=req.headers.authorization||''; const t=h.startsWith('Bearer ')?h.slice(7):null; if(!t)return res.status(401).json({message:'Authentication required'}); try{req.user=jwt.verify(t,JWT_SECRET);next()}catch(e){res.status(401).json({message:'Invalid or expired token'})} }
const roles=(...allowed)=>(req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({message:'Access denied'});
function error(res,e){ console.error(e); res.status(500).json({message:'Server error'}); }

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Burger House API',time:new Date().toISOString()}));

app.post('/api/auth/register',async(req,res)=>{try{const {name,email,password}=req.body;if(!name||!email||!password)return res.status(400).json({message:'Name, email and password are required'});const exists=await get('SELECT id FROM users WHERE email=?',[email.toLowerCase()]);if(exists)return res.status(409).json({message:'Email already registered'});const hash=await bcrypt.hash(password,10);const r=await run('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[name,email.toLowerCase(),hash,'customer']);const u=await get('SELECT id,name,email,role FROM users WHERE id=?',[r.lastID]);res.status(201).json({user:u,token:tokenFor(u)});}catch(e){error(res,e)}});
app.post('/api/auth/login',async(req,res)=>{try{const {email,password}=req.body;const u=await get('SELECT * FROM users WHERE email=?',[String(email||'').toLowerCase()]);if(!u||!(await bcrypt.compare(password||'',u.password_hash)))return res.status(401).json({message:'Invalid email or password'});const safe={id:u.id,name:u.name,email:u.email,role:u.role};res.json({user:safe,token:tokenFor(safe)});}catch(e){error(res,e)}});
app.get('/api/auth/me',auth,async(req,res)=>{const u=await get('SELECT id,name,email,role,created_at FROM users WHERE id=?',[req.user.id]);res.json(u)});

app.get('/api/products',async(req,res)=>{try{res.json(await all('SELECT p.*,COALESCE(i.stock,0) stock,COALESCE(i.minimum,10) minimum FROM products p LEFT JOIN inventory i ON i.product_id=p.id WHERE p.active=1 ORDER BY p.id'))}catch(e){error(res,e)}});
app.post('/api/products',auth,roles('admin'),async(req,res)=>{try{const {name,price,category,image,stock=0,minimum=10}=req.body;const r=await run('INSERT INTO products(name,price,category,image) VALUES(?,?,?,?)',[name,price,category,image||null]);await run('INSERT INTO inventory(product_id,stock,minimum) VALUES(?,?,?)',[r.lastID,stock,minimum]);res.status(201).json(await get('SELECT * FROM products WHERE id=?',[r.lastID]))}catch(e){error(res,e)}});
app.put('/api/products/:id',auth,roles('admin'),async(req,res)=>{try{const {name,price,category,image,active}=req.body;await run('UPDATE products SET name=COALESCE(?,name),price=COALESCE(?,price),category=COALESCE(?,category),image=COALESCE(?,image),active=COALESCE(?,active) WHERE id=?',[name,price,category,image,active,req.params.id]);res.json(await get('SELECT * FROM products WHERE id=?',[req.params.id]))}catch(e){error(res,e)}});
app.delete('/api/products/:id',auth,roles('admin'),async(req,res)=>{try{await run('UPDATE products SET active=0 WHERE id=?',[req.params.id]);res.json({message:'Product archived'})}catch(e){error(res,e)}});

app.get('/api/inventory',auth,roles('admin','staff'),async(req,res)=>{try{res.json(await all('SELECT i.*,p.name,p.category,p.price FROM inventory i JOIN products p ON p.id=i.product_id ORDER BY i.id'))}catch(e){error(res,e)}});
app.put('/api/inventory/:productId',auth,roles('admin','staff'),async(req,res)=>{try{const {stock,minimum}=req.body;await run('UPDATE inventory SET stock=COALESCE(?,stock),minimum=COALESCE(?,minimum),updated_at=CURRENT_TIMESTAMP WHERE product_id=?',[stock,minimum,req.params.productId]);res.json(await get('SELECT i.*,p.name,p.category FROM inventory i JOIN products p ON p.id=i.product_id WHERE i.product_id=?',[req.params.productId]))}catch(e){error(res,e)}});

app.post('/api/orders',async(req,res)=>{const {userId,customerName,customerEmail,paymentMethod='Cash',deliveryAddress,items}=req.body;const cx=()=>new Promise((resolve,reject)=>db.serialize(async()=>{try{if(!customerName||!Array.isArray(items)||!items.length)return reject({status:400,message:'Customer name and items are required'});const ids=items.map(x=>x.productId);const placeholders=ids.map(()=>'?').join(',');const ps=await all(`SELECT p.*,i.stock FROM products p JOIN inventory i ON i.product_id=p.id WHERE p.id IN (${placeholders}) AND p.active=1`,ids);let total=0;const normalized=[];for(const it of items){const p=ps.find(x=>x.id===Number(it.productId));const q=Number(it.quantity);if(!p||!Number.isInteger(q)||q<1)throw {status:400,message:'Invalid product or quantity'};if(p.stock<q)throw {status:400,message:`Not enough stock for ${p.name}`};const subtotal=p.price*q;total+=subtotal;normalized.push({...p,quantity:q,subtotal});}await run('BEGIN');const o=await run('INSERT INTO orders(user_id,customer_name,customer_email,total,status,payment_method,delivery_address) VALUES(?,?,?,?,?,?,?)',[userId||null,customerName,customerEmail||null,total,'Pending',paymentMethod,deliveryAddress||null]);for(const x of normalized){await run('INSERT INTO order_items(order_id,product_id,product_name,quantity,price,subtotal) VALUES(?,?,?,?,?,?)',[o.lastID,x.id,x.name,x.quantity,x.price,x.subtotal]);await run('UPDATE inventory SET stock=stock-?,updated_at=CURRENT_TIMESTAMP WHERE product_id=?',[x.quantity,x.id]);}await run('COMMIT');resolve(await get('SELECT * FROM orders WHERE id=?',[o.lastID]));}catch(e){try{await run('ROLLBACK')}catch(_){}reject(e)}}));try{res.status(201).json(await cx())}catch(e){res.status(e.status||500).json({message:e.message||'Server error'})}});
app.get('/api/orders',auth,async(req,res)=>{try{const isStaff=['admin','staff'].includes(req.user.role);const rows=isStaff?await all('SELECT o.*,u.email user_email FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.id DESC'):await all('SELECT * FROM orders WHERE user_id=? OR customer_email=? ORDER BY id DESC',[req.user.id,req.user.email]);for(const o of rows)o.items=await all('SELECT * FROM order_items WHERE order_id=?',[o.id]);res.json(rows)}catch(e){error(res,e)}});
app.patch('/api/orders/:id/status',auth,roles('admin','staff'),async(req,res)=>{try{const allowed=['Pending','Confirmed','Preparing','Out for Delivery','Completed','Cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({message:'Invalid status'});await run('UPDATE orders SET status=? WHERE id=?',[req.body.status,req.params.id]);res.json(await get('SELECT * FROM orders WHERE id=?',[req.params.id]))}catch(e){error(res,e)}});

app.get('/api/users',auth,roles('admin'),async(req,res)=>{try{res.json(await all('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC'))}catch(e){error(res,e)}});
app.patch('/api/users/:id/role',auth,roles('admin'),async(req,res)=>{try{if(!['customer','staff','admin'].includes(req.body.role))return res.status(400).json({message:'Invalid role'});await run('UPDATE users SET role=? WHERE id=?',[req.body.role,req.params.id]);res.json(await get('SELECT id,name,email,role,created_at FROM users WHERE id=?',[req.params.id]))}catch(e){error(res,e)}});

app.get('/api/reviews',async(req,res)=>{try{res.json(await all("SELECT * FROM reviews WHERE status='Published' ORDER BY id DESC"))}catch(e){error(res,e)}});
app.post('/api/reviews',auth,async(req,res)=>{try{const {rating,comment}=req.body;if(!Number.isInteger(Number(rating))||rating<1||rating>5||!comment)return res.status(400).json({message:'Rating and comment are required'});const r=await run('INSERT INTO reviews(user_id,customer_name,rating,comment) VALUES(?,?,?,?)',[req.user.id,req.user.name,rating,comment]);res.status(201).json(await get('SELECT * FROM reviews WHERE id=?',[r.lastID]))}catch(e){error(res,e)}});
app.patch('/api/reviews/:id/status',auth,roles('admin','staff'),async(req,res)=>{try{if(!['Published','Hidden'].includes(req.body.status))return res.status(400).json({message:'Invalid status'});await run('UPDATE reviews SET status=? WHERE id=?',[req.body.status,req.params.id]);res.json(await get('SELECT * FROM reviews WHERE id=?',[req.params.id]))}catch(e){error(res,e)}});

app.get('/api/dashboard',auth,roles('admin','staff'),async(req,res)=>{try{const [sales,orders,users,stock,low,recent]=await Promise.all([get("SELECT COALESCE(SUM(total),0) total FROM orders WHERE status!='Cancelled'"),get('SELECT COUNT(*) count FROM orders'),get('SELECT COUNT(*) count FROM users'),get('SELECT COALESCE(SUM(stock),0) count FROM inventory'),get('SELECT COUNT(*) count FROM inventory WHERE stock<=minimum'),all('SELECT * FROM orders ORDER BY id DESC LIMIT 8')]);res.json({sales:sales.total,orders:orders.count,users:users.count,stock:stock.count,lowStock:low.count,recentOrders:recent})}catch(e){error(res,e)}});

app.use(express.static(path.join(__dirname,'..','..')));
app.use((req,res)=>res.status(404).json({message:'Route not found'}));
app.listen(PORT,()=>console.log(`Burger House API running on http://localhost:${PORT}`));
