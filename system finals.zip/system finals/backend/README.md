# Burger House Backend + Database

This folder adds a Node.js/Express REST API and SQLite database **without modifying the existing frontend files**.

## Run

1. Install Node.js 18+.
2. Open a terminal in this `backend` folder.
3. Run `npm install`.
4. Run `npm start`.
5. API: `http://localhost:3000/api/health`

The server also serves the existing frontend from the parent folder, so the project can be opened through `http://localhost:3000/`.

## Demo accounts

- Admin: `admin@burgerhouse.com` / `admin123`
- Staff: `staff@burgerhouse.com` / `staff123`
- Customer: `customer@burgerhouse.com` / `customer123`

Change these passwords before real deployment.

## API groups

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET/POST/PUT/DELETE /api/products`
- `GET/PUT /api/inventory`
- `POST/GET /api/orders`
- `PATCH /api/orders/:id/status`
- `GET/PATCH /api/users`
- `GET/POST/PATCH /api/reviews`
- `GET /api/dashboard`

Protected routes use `Authorization: Bearer <token>`.

## Database

SQLite file: `data/burger-house.sqlite`

Tables: `users`, `products`, `inventory`, `orders`, `order_items`, `reviews`.
